import { db } from "../db";
import { pools, participants } from "@shared/schema";
import { eq, not, inArray } from "drizzle-orm";
import {
  unlockPoolOnChain,
  createRandomnessAccount,
  requestRandomness,
  revealRandomness,
  loadRandomnessValue,
  selectWinnerOnChain,
  payoutWinner,
} from "./solanaServices";
import { PublicKey } from "@solana/web3.js";

const POLL_INTERVAL = 5000;
const MAX_RETRIES = 3;

const log = (...args: any[]) => console.log("[PoolMonitor]", ...args);
const sep = () => console.log("─".repeat(50));

const processingPools = new Set<number>();
const retryCount = new Map<string, number>();

export class PoolMonitor {
  private intervalId: NodeJS.Timeout | null = null;
  private isRunning = false;

  start() {
    if (this.isRunning) {
      log("Monitor already running");
      return;
    }
    
    this.isRunning = true;
    log("Starting pool monitor...");
    
    this.intervalId = setInterval(() => this.tick(), POLL_INTERVAL);
    this.tick();
  }

  stop() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
    this.isRunning = false;
    log("Pool monitor stopped");
  }

  private async tick() {
    try {
      const activePools = await db
        .select()
        .from(pools)
        .where(
          not(
            inArray(pools.status, ["ended", "cancelled", "winnerSelected"])
          )
        );

      for (const pool of activePools) {
        if (!processingPools.has(pool.id)) {
          this.processPool(pool.id).catch(err => {
            log(`Error processing pool ${pool.id}:`, err.message);
            this.handleRetry(pool.id, "process");
            processingPools.delete(pool.id);
          });
        }
      }
    } catch (err) {
      log("Tick error:", err);
    }
  }

  private handleRetry(poolId: number, action: string) {
    const key = `${poolId}:${action}`;
    const count = (retryCount.get(key) ?? 0) + 1;
    retryCount.set(key, count);
    
    if (count >= MAX_RETRIES) {
      log(`Pool ${poolId} action ${action} failed ${count} times, will retry next tick`);
      retryCount.delete(key);
    }
  }

  private async processPool(poolId: number) {
    processingPools.add(poolId);
    
    try {
      sep();
      log(`Processing pool: ${poolId}`);

      const [pool] = await db.select().from(pools).where(eq(pools.id, poolId));
      if (!pool) {
        log(`Pool ${poolId} not found`);
        return;
      }

      const status = pool.status;
      log(`Pool ${poolId} status: ${status}, participants: ${pool.participantsCount}/${pool.maxParticipants}`);

      switch (status) {
        case "open":
          await this.handleOpen(pool);
          break;
        case "locked":
          await this.handleLocked(pool);
          break;
        case "unlocking":
          await this.handleUnlocking(pool);
          break;
        case "randomness":
          await this.handleRandomness(pool);
          break;
        case "ended":
        case "cancelled":
        case "winnerSelected":
          log(`Pool ${poolId} is ${status}, no action needed`);
          break;
        default:
          log(`Unknown status: ${status}`);
      }
    } finally {
      processingPools.delete(poolId);
    }
  }

  private async handleOpen(pool: typeof pools.$inferSelect) {
    const count = pool.participantsCount ?? 0;
    const max = pool.maxParticipants;

    if (count >= max) {
      log(`Pool ${pool.id} is full (${count}/${max}), transitioning to locked`);
      
      const now = Math.floor(Date.now() / 1000);
      await db.update(pools)
        .set({ 
          status: "locked",
          lockStartTime: now,
          lockTime: new Date()
        })
        .where(eq(pools.id, pool.id));
      
      log(`Pool ${pool.id} -> locked`);
    }
  }

  private async handleLocked(pool: typeof pools.$inferSelect) {
    const now = Math.floor(Date.now() / 1000);
    let lockStart = pool.lockStartTime;
    
    if (!lockStart) {
      lockStart = pool.lockTime ? Math.floor(pool.lockTime.getTime() / 1000) : now;
      await db.update(pools)
        .set({ lockStartTime: lockStart })
        .where(eq(pools.id, pool.id));
    }
    
    const lockDurationSeconds = (pool.lockDuration ?? 1) * 60;
    const unlockAt = lockStart + lockDurationSeconds;

    log(`Pool ${pool.id}: now=${now}, unlockAt=${unlockAt}, remaining=${Math.max(0, unlockAt - now)}s`);

    if (now >= unlockAt) {
      log(`Lock period ended for pool ${pool.id}, transitioning to unlocking...`);
      
      try {
        if (pool.poolAddress) {
          await unlockPoolOnChain(pool.poolAddress);
        }

        await db.update(pools)
          .set({ status: "unlocking" })
          .where(eq(pools.id, pool.id));
        
        log(`Pool ${pool.id} -> unlocking`);
      } catch (err) {
        log(`Failed to unlock pool ${pool.id}:`, err);
        this.handleRetry(pool.id, "unlock");
      }
    }
  }

  private async handleUnlocking(pool: typeof pools.$inferSelect) {
    log(`Pool ${pool.id} is unlocking, setting up randomness...`);

    try {
      if (!pool.randomnessAccount) {
        const result = await createRandomnessAccount(pool.poolAddress ?? `pool_${pool.id}`);
        const rngAddress = result.randomnessPda.toBase58();

        await db.update(pools)
          .set({ randomnessAccount: rngAddress })
          .where(eq(pools.id, pool.id));
        
        log(`Randomness account created: ${rngAddress}`);
        return;
      }

      await requestRandomness(pool.poolAddress ?? `pool_${pool.id}`, pool.randomnessAccount);

      await db.update(pools)
        .set({ status: "randomness" })
        .where(eq(pools.id, pool.id));
      
      log(`Pool ${pool.id} -> randomness`);
    } catch (err) {
      log(`Failed randomness setup for pool ${pool.id}:`, err);
      this.handleRetry(pool.id, "randomness");
    }
  }

  private async handleRandomness(pool: typeof pools.$inferSelect) {
    log(`Pool ${pool.id} processing randomness and selecting winner...`);

    try {
      if (!pool.randomnessAccount) {
        log(`No randomness account for pool ${pool.id}`);
        return;
      }

      const rngPk = new PublicKey(pool.randomnessAccount);
      
      await revealRandomness(rngPk);
      const hex = await loadRandomnessValue(rngPk);

      if (!hex || /^0x0+$/.test(hex)) {
        log(`Invalid randomness for pool ${pool.id}, will retry`);
        return;
      }

      await db.update(pools)
        .set({ randomnessHex: hex })
        .where(eq(pools.id, pool.id));

      await selectWinnerOnChain(pool.poolAddress ?? `pool_${pool.id}`, pool.randomnessAccount);

      const poolParticipants = await db
        .select()
        .from(participants)
        .where(eq(participants.poolId, pool.id));

      if (poolParticipants.length === 0) {
        log(`No participants in pool ${pool.id}, cancelling`);
        await db.update(pools)
          .set({ status: "cancelled" })
          .where(eq(pools.id, pool.id));
        return;
      }

      const result = await payoutWinner(
        pool.poolAddress ?? `pool_${pool.id}`,
        poolParticipants,
        hex
      );

      await db.update(pools)
        .set({ 
          status: "winnerSelected",
          winnerWallet: result.winner,
          txHash: result.tx,
          endTime: new Date()
        })
        .where(eq(pools.id, pool.id));
      
      log(`Pool ${pool.id} -> winnerSelected`);
      log(`Winner: ${result.winner}`);
      log(`Tx: ${result.tx.substring(0, 30)}...`);
    } catch (err) {
      log(`Failed randomness/payout for pool ${pool.id}:`, err);
      this.handleRetry(pool.id, "payout");
    }
  }

  getStatus() {
    return {
      running: this.isRunning,
      processingCount: processingPools.size,
      processingPools: Array.from(processingPools),
      retries: Object.fromEntries(retryCount)
    };
  }
}

export const poolMonitor = new PoolMonitor();
