import prisma from "../../db";
import { RewardsProgram } from "../programs/rewards";
import { sendAndConfirm } from "../core/tx";
import { buildTx } from "../core/tx";
import { SolanaClient } from "../client/solana-client";
import { v4 as uuidv4 } from "uuid";
import * as anchor from "@coral-xyz/anchor";
export async function claimReferralRewards(user: any): Promise<{ totalClaimed: number; txLinks: string[] }> {
  const client = await SolanaClient.getInstance();
  const txLinks: string[] = [];
  let totalClaimed = 0;
  const kp = await client.getUserKeypair(user);
  const provider = client.createProvider(kp);
  const program = new RewardsProgram(client.getProgram());
  const rewards = await prisma.referralReward.findMany({
    where: { referrerId: user.tgId, claimed: false },
  });
  if (!rewards.length) throw new Error("No unclaimed rewards");
  for (const r of rewards) {
    const ix = await program.claimReferralRewards({
      user: kp.publicKey,
      systemProgram: anchor.web3.SystemProgram.programId,
    });
    const tx = await buildTx(kp, [ix]);
    const sig = await sendAndConfirm(tx, uuidv4(), `claim:${r.id}`);
    await prisma.referralReward.update({
      where: { id: r.id },
      data: { claimed: true, claimedAt: new Date(), claimTx: sig },
    });
    totalClaimed += Number(r.amount ?? 0);
    txLinks.push(`https://solscan.io/tx/${sig}?cluster=devnet`);
  }
  return { totalClaimed, txLinks };
}