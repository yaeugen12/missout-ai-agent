import {
  PublicKey,
  Keypair,
  SystemProgram,
} from "@solana/web3.js";
import { getAssociatedTokenAddressSync } from "@solana/spl-token";
import * as anchor from "@coral-xyz/anchor";

import prisma from "../../db";
import { SolanaClient } from "../client/solana-client";
import { derivePoolTokenAddress } from "../pda/derive";
import { redis } from "../core/redis";
import { buildTx, sendAndConfirm } from "../core/tx";
import { v4 as uuidv4 } from "uuid";
import crypto from "crypto";

import {
  AnchorUtils,
  Randomness,
} from "@switchboard-xyz/on-demand";

/* ======================================================================== */
/* CONFIG                                                                   */
/* ======================================================================== */

const SWITCHBOARD_PID = new PublicKey(process.env.SWITCHBOARD_PROGRAM_ID!);
const SWITCHBOARD_QUEUE = new PublicKey(process.env.SWITCHBOARD_QUEUE!);

const ENV_MOCK = process.env.USE_MOCK_RANDOMNESS === "true";

/* Log only meaningful events */
const log = (...a: any[]) => console.log("[RNG]", ...a);

/* ======================================================================== */
/* MOCK HELPERS                                                             */
/* ======================================================================== */

async function isMockForPool(poolId: string) {
  if (ENV_MOCK) return true;

  try {
    const pool = await prisma.pool.findUnique({
      where: { id: poolId },
      select: { allowMock: true },
    });
    return !!pool?.allowMock;
  } catch {
    return false;
  }
}

/**
 * Useful when only randomnessPk is available (reveal/load stage).
 * We infer mock from DB association with a pool.
 */
async function isMockByRandomnessPk(rngPk: PublicKey) {
  if (ENV_MOCK) return true;

  try {
    const pool = await prisma.pool.findFirst({
      where: { randomnessAccount: rngPk.toBase58() },
      select: { allowMock: true },
    });
    return !!pool?.allowMock;
  } catch {
    return false;
  }
}

/* ======================================================================== */
/* LOAD SWITCHBOARD PROGRAM                                                 */
/* ======================================================================== */

async function loadSwitchboardProgram(conn: any, wallet: any) {
  const sbProvider = new anchor.AnchorProvider(conn, wallet, {
    commitment: "confirmed",
  });

  const oldProvider = anchor.getProvider();
  anchor.setProvider(sbProvider);

  const program = AnchorUtils.loadProgramFromConnection(
    conn,
    wallet,
    SWITCHBOARD_PID
  );

  anchor.setProvider(oldProvider);
  return program;
}

/* ======================================================================== */
/* GET PARTICIPANTS PDA                                                     */
/* ======================================================================== */

async function getParticipantsPda(poolPk: PublicKey) {
  const client = await SolanaClient.getInstance();
  const coder = client.getCoder();
  const conn = client.getConnection();

  const acc = await conn.getAccountInfo(poolPk);
  if (!acc) throw new Error("Pool not found");

  const pool = coder.decode("pool", acc.data);
  return pool.participantsAccount as PublicKey;
}

/* ======================================================================== */
/* CREATE RANDOMNESS ACCOUNT                                                */
/* ======================================================================== */

/** Creates a new Switchboard V4 randomness account for a pool. */
export async function createRandomnessAccountForPool(poolId: string) {
  log("Creating randomness account for pool:", poolId);

  const client = await SolanaClient.getInstance();
  const payer = client.getServiceKeypair();
  const conn = client.getConnection();
  const wallet = new anchor.Wallet(payer);

  const sbProgram = await loadSwitchboardProgram(conn, wallet);
  const rngKeypair = Keypair.generate();

  const [rngObj, createIx] = await Randomness.create(
    sbProgram,
    rngKeypair,
    SWITCHBOARD_QUEUE
  );

  const tx = await buildTx(payer, [createIx], {
    additionalSigners: [rngKeypair],
  });

  const sig = await sendAndConfirm(tx, uuidv4(), `rng-create:${poolId}`, {
    redis,
  });

  log("✔ Randomness account created:", sig);

  await prisma.pool.update({
    where: { id: poolId },
    data: { randomnessAccount: rngObj.pubkey.toBase58() },
  });

  return { randomnessPda: rngObj.pubkey };
}

/* ======================================================================== */
/* REQUEST RANDOMNESS                                                       */
/* ======================================================================== */

/**
 * REAL:
 *   - commitIx on SB
 *   - call pool.requestRandomness with actual rngPk
 *
 * MOCK:
 *   - skip SB commit
 *   - call pool.requestRandomness with SystemProgram as sentinel
 *     (matches your on-chain "is_mock" condition)
 */
export async function requestRandomnessForPool(poolId: string, randomness: string) {
  log("Requesting randomness for pool:", poolId);

  const client = await SolanaClient.getInstance();
  const payer = client.getServiceKeypair();
  const conn = client.getConnection();
  const program = client.getServiceProgram();

  const wallet = new anchor.Wallet(payer);
  const sbProgram = await loadSwitchboardProgram(conn, wallet);

  const poolPk = new PublicKey(poolId);
  const rngPk = new PublicKey(randomness);
  const participantsPda = await getParticipantsPda(poolPk);

  const mock = await isMockForPool(poolId);

  // -------------------------
  // REAL: commit
  // -------------------------
  if (!mock) {
    const rng = new Randomness(sbProgram, rngPk);

    const commitIx = await rng.commitIx(SWITCHBOARD_QUEUE);
    const txCommit = await buildTx(payer, [commitIx]);

    await sendAndConfirm(txCommit, uuidv4(), `rng-commit:${poolId}`, { redis });
    log("✔ Commit completed");
  } else {
    log("🧪 Mock mode: skipping Switchboard commit");
  }

  // -------------------------
  // IMPORTANT:
  // mock must pass sentinel to your program
  // -------------------------
  const randomnessForIx = mock ? SystemProgram.programId : rngPk;

  const ixPool = await program.methods
    .requestRandomness()
    .accounts({
      pool: poolPk,
      randomness: randomnessForIx,
      user: payer.publicKey,
      participants: participantsPda,
    })
    .instruction();

  const txPool = await buildTx(payer, [ixPool]);

  // Avoid idempotency collisions between real/mock
  const idemKey = mock
    ? `pool.request.mock:${poolId}`
    : `pool.request:${poolId}`;

  await sendAndConfirm(txPool, uuidv4(), idemKey, { redis });

  log("✔ Pool requestRandomness executed");

  return true;
}

/* ======================================================================== */
/* REVEAL RANDOMNESS                                                        */
/* ======================================================================== */

export async function revealRandomnessOnChain(rngPk: PublicKey) {
  const mock = await isMockByRandomnessPk(rngPk);

  if (mock) {
    log("🧪 Mock mode: skipping reveal for", rngPk.toBase58());
    return "mock-skip";
  }

  log("Revealing randomness on-chain:", rngPk.toBase58());

  const client = await SolanaClient.getInstance();
  const payer = client.getServiceKeypair();
  const conn = client.getConnection();

  const wallet = new anchor.Wallet(payer);
  const sbProgram = await loadSwitchboardProgram(conn, wallet);
  const rng = new Randomness(sbProgram, rngPk);

  try {
    const before = await rng.loadData();
    if (before.revealSlot.toString() !== "0") {
      log("✔ Already revealed — skipping");
      return;
    }
  } catch {}

  // small delay for block progression
  await new Promise((r) => setTimeout(r, 3000));

  let lastError: any = null;

  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      const revealIx = await rng.revealIx();
      const tx = await buildTx(payer, [revealIx]);

      const sig = await sendAndConfirm(tx, uuidv4(), "rng-reveal-direct", { redis });
      log("✔ Reveal transaction sent:", sig);

      const after = await rng.loadData();
      const valueHex = Buffer.from(after.value).toString("hex");

      if (after.revealSlot.toString() === "0")
        throw new Error("Reveal incomplete");

      if (/^0+$/.test(valueHex))
        throw new Error("Invalid randomness (all zeros)");

      log("✔ Valid randomness produced");
      return sig;
    } catch (err) {
      lastError = err;
      if (attempt < 3) {
        await new Promise((r) => setTimeout(r, 1200));
      }
    }
  }

  log("❌ Reveal failed after 3 attempts");
  throw lastError;
}

/* ======================================================================== */
/* LOAD RANDOMNESS VALUE                                                    */
/* ======================================================================== */

export async function loadRandomnessValueOnChain(rngPk: PublicKey) {
  const rngStr = rngPk.toBase58();

  const pool = await prisma.pool.findFirst({
    where: { randomnessAccount: rngStr },
    select: { id: true, randomnessHex: true, allowMock: true },
  });

  const mock = ENV_MOCK || !!pool?.allowMock;

  if (mock) {
    if (pool?.randomnessHex && !/^0x0+$/.test(pool.randomnessHex)) {
      return pool.randomnessHex;
    }

    const fake = "0x" + crypto.randomBytes(16).toString("hex");

    if (pool?.id) {
      await prisma.pool.update({
        where: { id: pool.id },
        data: { randomnessHex: fake, allowMock: true },
      });
    }

    return fake;
  }

  const client = await SolanaClient.getInstance();
  const conn = client.getConnection();
  const wallet = new anchor.Wallet(client.getServiceKeypair());

  const sbProgram = await loadSwitchboardProgram(conn, wallet);
  const rng = new Randomness(sbProgram, rngPk);

  const data = await rng.loadData();
  return "0x" + Buffer.from(data.value).toString("hex");
}

/* ======================================================================== */
/* UNLOCK POOL                                                              */
/* ======================================================================== */

export async function unlockPoolForService(poolId: string) {
  const client = await SolanaClient.getInstance();
  const payer = client.getServiceKeypair();
  const program = client.getServiceProgram();
  const conn = client.getConnection();
  const coder = client.getCoder();

  const poolPk = new PublicKey(poolId);
  const acc = await conn.getAccountInfo(poolPk);

  if (!acc) throw new Error("Pool not found");

  const pool = coder.decode("pool", acc.data);
  if (Object.keys(pool.status)[0] !== "locked")
    throw new Error("Pool not locked");

  const participantsPda = await getParticipantsPda(poolPk);

  const ix = await program.methods
    .unlockPool()
    .accounts({
      pool: poolPk,
      user: payer.publicKey,
      participants: participantsPda,
    })
    .instruction();

  const tx = await buildTx(payer, [ix]);
  const sig = await sendAndConfirm(tx, uuidv4(), undefined, { redis });

  log("✔ Pool unlocked");
  return { poolId, tx: sig };
}

/* ======================================================================== */
/* SELECT WINNER                                                            */
/* ======================================================================== */

export async function selectWinnerForService(poolId: string, randomnessAccount: string) {
  log("Selecting winner for pool:", poolId);

  const client = await SolanaClient.getInstance();
  const payer = client.getServiceKeypair();
  const program = client.getServiceProgram();

  const poolPk = new PublicKey(poolId);
  const randPk = new PublicKey(randomnessAccount);
  const participantsPda = await getParticipantsPda(poolPk);

  const mock = await isMockForPool(poolId);

  // Future-proof: in mock pass sentinel
  const randomnessForIx = mock ? SystemProgram.programId : randPk;

  const ix = await program.methods
    .selectWinner()
    .accounts({
      pool: poolPk,
      randomness: randomnessForIx,
      user: payer.publicKey,
      participants: participantsPda,
    })
    .instruction();

  const tx = await buildTx(payer, [ix]);

  const idemKey = mock
    ? `selectWinner.mock:${poolId}`
    : `selectWinner:${poolId}`;

  const sig = await sendAndConfirm(tx, uuidv4(), idemKey, { redis });

  log("✔ Winner selected");
  return sig;
}

/* ======================================================================== */
/* PAYOUT WINNER                                                            */
/* ======================================================================== */

export async function payoutWinnerForService(poolId: string) {
  log("Processing payout for pool:", poolId);

  const client = await SolanaClient.getInstance();
  const payer = client.getServiceKeypair();
  const program = client.getServiceProgram();
  const conn = client.getConnection();
  const coder = client.getCoder();

  const poolPk = new PublicKey(poolId);
  const acc = await conn.getAccountInfo(poolPk);

  if (!acc) throw new Error("Pool not found");

  const pool = coder.decode("pool", acc.data);
  if (Object.keys(pool.status)[0] !== "winnerSelected")
    throw new Error("Invalid pool status");

  const participantsPda = await getParticipantsPda(poolPk);

  const mintPk = new PublicKey(pool.mint);
  const winnerPk = new PublicKey(pool.winner);
  const devPk = new PublicKey(pool.devWallet);
  const treasuryPk = new PublicKey(pool.treasuryWallet);

  const poolToken = derivePoolTokenAddress(mintPk, poolPk);
  const winnerAta = getAssociatedTokenAddressSync(mintPk, winnerPk);
  const devAta = getAssociatedTokenAddressSync(mintPk, devPk);
  const treasuryAta = getAssociatedTokenAddressSync(mintPk, treasuryPk);

  const ix = await program.methods
    .payoutWinner()
    .accountsStrict({
      mint: mintPk,
      pool: poolPk,
      poolToken,
      winnerToken: winnerAta,
      devToken: devAta,
      treasuryToken: treasuryAta,
      participants: participantsPda,
      winnerPubkey: winnerPk,
      user: payer.publicKey,
      tokenProgram: anchor.utils.token.TOKEN_PROGRAM_ID,
      associatedTokenProgram: anchor.utils.token.ASSOCIATED_PROGRAM_ID,
      systemProgram: anchor.web3.SystemProgram.programId,
    })
    .instruction();

  const tx = await buildTx(payer, [ix]);
  const sig = await sendAndConfirm(tx, uuidv4(), `payout:${poolId}`, {
    redis,
  });

  log("✔ Payout completed");

  return {
    poolId,
    winner: winnerPk.toBase58(),
    tx: sig,
  };
}

/* ======================================================================== */
/* EXPORTS                                                                  */
/* ======================================================================== */

export const createRandomnessAccount = createRandomnessAccountForPool;
export const requestRandomness = requestRandomnessForPool;
export const unlockPool = unlockPoolForService;
export const selectWinner = selectWinnerForService;
export const payoutWinner = payoutWinnerForService;
export const revealRandomness = revealRandomnessOnChain;
export const loadRandomness = loadRandomnessValueOnChain;
