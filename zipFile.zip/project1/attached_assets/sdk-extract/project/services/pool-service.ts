import * as anchor from "@coral-xyz/anchor";
import BN from "bn.js";
import {
  getAssociatedTokenAddressSync,
  getOrCreateAssociatedTokenAccount
} from "@solana/spl-token";
import { PublicKey } from "@solana/web3.js";

import prisma from "../../db";
import { DistributedLock } from "../core/locks";
import { CacheManager } from "../core/cache";

import { consensusRead } from "../core/consensus";
import { TokenAmount } from "../utils/token";

import {
  derivePoolPda,
  deriveParticipantsPda,
  derivePoolTokenAddress
} from "../pda/derive";

import { SolanaClient } from "../client/solana-client";
import { redis } from "../core/redis";
import { buildTx, sendAndConfirm } from "../core/tx";

import { v4 as uuidv4 } from "uuid";

const lock = new DistributedLock(redis, 3000, 1000);

/* ====================================================================================
   SYNC POOL STATE
==================================================================================== */
export async function syncPoolState(poolId: string) {
  const client = await SolanaClient.getInstance();
  const coder = client.getCoder();

  const poolPk = new PublicKey(poolId);

  // --- LOAD POOL ACCOUNT SAFELY ---
  const acc = await consensusRead(poolPk);
  if (!acc) throw new Error("Pool not found");

  let data: any;
  try {
    data = coder.decode("pool", acc.data);
  } catch (e) {
    console.error("❌ Failed to decode pool account", e);
    throw new Error("Invalid pool account data");
  }

  // --- LOAD PARTICIPANTS COUNT SAFELY ---
  let participantsCount = 0;

  const [participantsPda] = deriveParticipantsPda(poolPk);
  const partAcc = await consensusRead(participantsPda).catch(() => null);

  if (partAcc) {
    try {
      const decoded = coder.decode("participants", partAcc.data);
      participantsCount = decoded.count ?? 0;
    } catch {
      // Not anchor-initialized yet → treat as 0
      participantsCount = 0;
    }
  }

  // --- UPDATE ONLY SAFE FIELDS ---
  return prisma.pool.update({
    where: { id: poolId },
    data: {
      currentParticipants: participantsCount,
      maxParticipants: data.maxParticipants,
      tokenMint: data.mint.toBase58(),

      lockStartTime:
        Number(data.lockStartTime) > 0
          ? BigInt(Number(data.lockStartTime))
          : undefined,

      lockDurationSeconds:
        data.lockDuration
          ? BigInt(Number(data.lockDuration))
          : undefined,
    },
  });
}

/* ====================================================================================
   CREATE POOL  (clean production version – FINAL)
==================================================================================== */
export async function createPool(params: {
  user: any;
  mint: string;
  amount: number | string;
  maxParticipants: number;
  lockDuration: number;
  devFeeBps: number;
  burnFeeBps: number;
  treasuryFeeBps: number;
  treasuryWallet: string;
  allowMock?: boolean;
}) {
  return lock.withLock(`create:${params.user.tgId}`, "create-pool", async () => {
    const {
      user,
      mint,
      amount,
      maxParticipants,
      lockDuration,
      devFeeBps,
      burnFeeBps,
      treasuryFeeBps,
      treasuryWallet,
      allowMock = false,
    } = params;

    const client = await SolanaClient.getInstance();

    // USER WALLET
    const userKp = await client.getUserKeypair(user);
    const program = await client.getProgramForUser(user);
    const userPk = userKp.publicKey;

    // DEVELOPER WALLET (service wallet ONLY)
    const devWallet = client.getDevPubkey();

    const mintPk = new PublicKey(mint);
    const treasuryPk = new PublicKey(treasuryWallet);

    const amountTA = await TokenAmount.fromTokens(
      amount,
      mintPk,
      client.getConnection()
    );

    const salt = anchor.utils.bytes.utf8.encode(uuidv4()).slice(0, 32);

    const [poolPda] = derivePoolPda(mintPk, salt);
    const [participantsPda] = deriveParticipantsPda(poolPda);

    const poolTokenAta = derivePoolTokenAddress(mintPk, poolPda);
    const userAta = getAssociatedTokenAddressSync(mintPk, userPk);

    /* ---- CREATE POOL INSTRUCTION ---- */
    const ix = await program.methods
      .createPool(
        Array.from(salt),
        maxParticipants,
        new BN(lockDuration),
        amountTA.toBN(),
        devWallet,   // ALWAYS service wallet
        devFeeBps,
        burnFeeBps,
        treasuryPk,
        treasuryFeeBps,
        allowMock
      )
      .accounts({
        user: userPk,
        mint: mintPk,
        pool: poolPda,
        participants: participantsPda,
        poolToken: poolTokenAta,
        userToken: userAta,
        systemProgram: anchor.web3.SystemProgram.programId,
        tokenProgram: anchor.utils.token.TOKEN_PROGRAM_ID,
        associatedTokenProgram: anchor.utils.token.ASSOCIATED_PROGRAM_ID,
        rent: anchor.web3.SYSVAR_RENT_PUBKEY,
      })
      .instruction();

    /* ---- SEND TX ---- */
    const tx = await buildTx(userKp, [ix]);
    const sig = await sendAndConfirm(tx, uuidv4(), `create:${poolPda}`, { redis });

    /* ---- SAVE POOL IN DB ---- */
    await prisma.pool.create({
      data: {
        id: poolPda.toBase58(),
        creatorId: BigInt(user.tgId),

        devWallet: devWallet.toBase58(),
        devWalletTgId: null,

        tokenMint: mintPk.toBase58(),
        poolTokenAddress: poolTokenAta.toBase58(),

        amountPerJoinLamports: amountTA.lamports,
        amountPerJoinTokens: amountTA.toTokens(),
        decimals: amountTA.decimals,

        maxParticipants,
        currentParticipants: 1,
        minParticipants: 2,
        lockDurationSeconds: BigInt(lockDuration),

        devFeeBps,
        burnFeeBps,
        treasuryFeeBps,
        treasuryWallet: treasuryPk.toBase58(),

        participantsPda: participantsPda.toBase58(),
        poolSalt: Buffer.from(salt).toString("hex"),

        allowMock,
        status: "open",
        txHash: sig,
      },
    });

    /* ---- SAVE CREATOR AS PARTICIPANT ---- */
    await prisma.participant.create({
      data: {
        poolId: poolPda.toBase58(),
        userId: BigInt(user.tgId),
        walletPubkey: userPk.toBase58(),
        amount: amountTA.lamports,
        isCreator: true,
      },
    });

    return { pool: poolPda.toBase58(), tx: sig };
  });
}

/* ====================================================================================
   JOIN POOL
==================================================================================== */
export async function joinPool(params: {
  user: any;
  poolId: string;
  amount: number | string;
}) {
  const { user, poolId, amount } = params;

  return lock.withLock(`join:${poolId}`, "join", async () => {
    const client = await SolanaClient.getInstance();

    const userKp = await client.getUserKeypair(user);
    const program = await client.getProgramForUser(user);
    const userPk = userKp.publicKey;

    const state = await client.getPoolState(poolId);
    if (!state) throw new Error("Pool not found");

    const mintPk = new PublicKey(state.mint);
    const poolPk = new PublicKey(poolId);

    const lamports = await TokenAmount.fromTokens(amount, mintPk, client.getConnection());

    const [participantsPda] = deriveParticipantsPda(poolPk);
    const poolTokenAta = derivePoolTokenAddress(mintPk, poolPk);
    const userAta = getAssociatedTokenAddressSync(mintPk, userPk);

    const ix = await program.methods
      .joinPool(lamports.toBN())
      .accounts({
        user: userPk,
        pool: poolPk,
        mint: mintPk,
        participants: participantsPda,
        poolToken: poolTokenAta,
        userToken: userAta,
        tokenProgram: anchor.utils.token.TOKEN_PROGRAM_ID,
      })
      .instruction();

    const tx = await buildTx(userKp, [ix]);
    const sig = await sendAndConfirm(
      tx,
      uuidv4(),
      `join:${poolId}:${userPk}`,
      { redis }
    );

    await prisma.participant.upsert({
      where: {
        poolId_walletPubkey: {
          poolId,
          walletPubkey: userPk.toBase58(),
        },
      },
      create: {
        poolId,
        userId: BigInt(user.tgId),
        walletPubkey: userPk.toBase58(),
        amount: lamports.lamports,
      },
      update: {
        amount: lamports.lamports,
      },
    });

    await syncPoolState(poolId);

    return { poolId, tx: sig, amount: lamports.toTokens() };
  });
}

export async function donate(params: {
  user: any;
  poolId: string;
  amount: number | string;
}) {
  const { user, poolId, amount } = params;

  return lock.withLock(`donate:${poolId}`, "donate", async () => {
    const client = await SolanaClient.getInstance();

    const userKp = await client.getUserKeypair(user);
    const program = await client.getProgramForUser(user);
    const userPk = userKp.publicKey;

    const poolPk = new PublicKey(poolId);

    const acc = await consensusRead(poolPk);
    if (!acc) throw new Error("Pool not found");

    const coder = client.getCoder();
    const raw: any = coder.decode("pool", acc.data);
    const mintPk = raw.mint as PublicKey;

    const lamports = await TokenAmount.fromTokens(
      amount,
      mintPk,
      client.getConnection()
    );

    const [participantsPda] = deriveParticipantsPda(poolPk);
    const poolToken = derivePoolTokenAddress(mintPk, poolPk);
    const userToken = getAssociatedTokenAddressSync(mintPk, userPk);

    const ix = await program.methods
      .donate(lamports.toBN())
      .accounts({
        mint: mintPk,
        pool: poolPk,
        poolToken,
        userToken,
        user: userPk,
        participants: participantsPda,
        tokenProgram: anchor.utils.token.TOKEN_PROGRAM_ID,
      })
      .instruction();

    const tx = await buildTx(userKp, [ix]);
    const sig = await sendAndConfirm(tx, uuidv4(), `donate:${poolId}`, { redis });

    await prisma.donation.create({
      data: {
        poolId,
        userId: BigInt(user.tgId),
        walletPubkey: userPk.toBase58(),
        amount: lamports.lamports,
        txHash: sig,
      },
    });

    return { poolId, tx: sig, amount: lamports.toTokens() };
  });
}

export async function cancelPool(params: { user: any; poolId: string }) {
  const { user, poolId } = params;

  return lock.withLock(`cancel:${poolId}`, "cancel", async () => {
    const client = await SolanaClient.getInstance();

    const userKp = await client.getUserKeypair(user);
    const program = await client.getProgramForUser(user);
    const userPk = userKp.publicKey;

    const poolPk = new PublicKey(poolId);

    const acc = await consensusRead(poolPk);
    if (!acc) throw new Error("Pool not found");

    const coder = client.getCoder();
    const raw: any = coder.decode("pool", acc.data);

    if (!raw.creator.equals(userPk) && !raw.devWallet.equals(userPk)) {
      throw new Error("Only creator or dev can cancel pool");
    }

    const mintPk = raw.mint;
    const [participantsPda] = deriveParticipantsPda(poolPk);

    const poolToken = derivePoolTokenAddress(mintPk, poolPk);
    const userToken = getAssociatedTokenAddressSync(mintPk, userPk);

    const ix = await program.methods
      .cancelPool()
      .accounts({
        mint: mintPk,
        pool: poolPk,
        participants: participantsPda,
        poolToken,
        userToken,
        user: userPk,
        tokenProgram: anchor.utils.token.TOKEN_PROGRAM_ID,
        systemProgram: anchor.web3.SystemProgram.programId,
      })
      .instruction();

    const tx = await buildTx(userKp, [ix]);
    const sig = await sendAndConfirm(tx, uuidv4(), `cancel:${poolId}`, { redis });

    await prisma.pool.update({
      where: { id: poolId },
      data: { status: "cancelled", ended: true },
    });

    return { poolId, tx: sig };
  });
}

export async function claimRefund(params: { user: any; poolId: string }) {
  const { user, poolId } = params;

  return lock.withLock(`refund:${poolId}`, "refund", async () => {
    const client = await SolanaClient.getInstance();
    const userKp = await client.getUserKeypair(user);
    const program = await client.getProgramForUser(user);
    const userPk = userKp.publicKey;

    const poolPk = new PublicKey(poolId);

    const acc = await consensusRead(poolPk);
    if (!acc) throw new Error("Pool not found");

    const raw: any = client.getCoder().decode("pool", acc.data);
    const mintPk = raw.mint;

    const status =
      raw.status.__kind?.toLowerCase() ??
      Object.keys(raw.status)[0].toLowerCase();

    if (status !== "cancelled") throw new Error("Pool not cancelled");

    const [partsPda] = deriveParticipantsPda(poolPk);
    const poolToken = derivePoolTokenAddress(mintPk, poolPk);

    const userAta = await getOrCreateAssociatedTokenAccount(
      client.getConnection(),
      userKp,
      mintPk,
      userPk
    );

    const treasuryPk = new PublicKey(raw.treasuryWallet);
    const treasuryToken = getAssociatedTokenAddressSync(mintPk, treasuryPk);

    const ix = await program.methods
      .claimRefund()
      .accounts({
        mint: mintPk,
        pool: poolPk,
        poolToken,
        userToken: userAta.address,
        treasuryToken,
        user: userPk,
        participants: partsPda,
        tokenProgram: anchor.utils.token.TOKEN_PROGRAM_ID,
      })
      .instruction();

    const tx = await buildTx(userKp, [ix]);
    const sig = await sendAndConfirm(tx, uuidv4(), `refund:${poolId}`, { redis });

    await prisma.participant.updateMany({
      where: { poolId, walletPubkey: userPk.toBase58() },
      data: { amount: BigInt(0) },
    });

    return { poolId, tx: sig, user: userPk.toBase58() };
  });
}

export async function claimRent(params: { user: any; poolId: string }) {
  const { user, poolId } = params;

  return lock.withLock(`claimRent:${poolId}`, "claim-rent", async () => {
    const client = await SolanaClient.getInstance();

    const userKp = await client.getUserKeypair(user);
    const program = await client.getProgramForUser(user);
    const userPk = userKp.publicKey;

    const poolPk = new PublicKey(poolId);

    /* -------------------------------------------------------
       1️⃣ LOAD POOL ACCOUNT FROM CHAIN
    -------------------------------------------------------- */
    const acc = await consensusRead(poolPk);
    if (!acc) throw new Error("Pool not found");

    const coder = client.getCoder();
    const rawPool: any = coder.decode("pool", acc.data);

    const mintPk = rawPool.mint;
    const devWallet = rawPool.devWallet as PublicKey;
    const creatorWallet = rawPool.creator as PublicKey;

    /* -------------------------------------------------------
       2️⃣ ALLOWED RENT RECIPIENTS
       - creator: anytime after pool is ended
       - dev wallet: only after forfeit delay
    -------------------------------------------------------- */
    const isCreator = creatorWallet.equals(userPk);
    const isDev = devWallet.equals(userPk);

    if (!isCreator && !isDev) {
      throw new Error("Unauthorized rent claim");
    }

    /* -------------------------------------------------------
       3️⃣ CHECK TIME REQUIREMENTS (DEV wallet only)
    -------------------------------------------------------- */
    const now = Math.floor(Date.now() / 1000);
    const closeTime = Number(rawPool.closeTime ?? rawPool.close_time ?? 0);

    const FORFEIT_DELAY = 30 * 86400; // 30 days

    if (isDev && now < closeTime + FORFEIT_DELAY) {
      throw new Error("Dev cannot claim rent yet");
    }

    const rentRecipient = isCreator ? creatorWallet : devWallet;

    /* -------------------------------------------------------
       4️⃣ PREP ACCOUNTS
    -------------------------------------------------------- */
    const poolToken = derivePoolTokenAddress(mintPk, poolPk);
    const [participantsPda] = deriveParticipantsPda(poolPk);

    /* -------------------------------------------------------
       5️⃣ BUILD INSTRUCTION
    -------------------------------------------------------- */
    const ix = await program.methods
      .claimRent()
      .accounts({
        pool: poolPk,
        mint: mintPk,
        poolToken,
        closeTarget: rentRecipient,
        user: userPk,
        participants: participantsPda,
        tokenProgram: anchor.utils.token.TOKEN_PROGRAM_ID,
        systemProgram: anchor.web3.SystemProgram.programId,
      })
      .instruction();

    /* -------------------------------------------------------
       6️⃣ SEND TX
    -------------------------------------------------------- */
    const tx = await buildTx(userKp, [ix]);
    const sig = await sendAndConfirm(
      tx,
      uuidv4(),
      `claimRent:${poolId}:${userPk.toBase58()}`,
      { redis }
    );

    /* -------------------------------------------------------
       7️⃣ DB UPDATE (minimal)
    -------------------------------------------------------- */
    await prisma.pool.update({
      where: { id: poolId },
      data: {
        rentClaimed: true,
      },
    });

    return {
      poolId,
      tx: sig,
      rentRecipient: rentRecipient.toBase58(),
    };
  });
}

export async function pausePool(params: { user: any; poolId: string }) {
  const { user, poolId } = params;

  return lock.withLock(`pause:${poolId}`, "pause", async () => {
    const client = await SolanaClient.getInstance();

    const kp = await client.getUserKeypair(user);
    const program = await client.getProgramForUser(user);
    const pk = kp.publicKey;

    const poolPk = new PublicKey(poolId);
    const [partsPda] = deriveParticipantsPda(poolPk);

    const ix = await program.methods
      .pausePool()
      .accounts({
        pool: poolPk,
        user: pk,
        participants: partsPda,
      })
      .instruction();

    const tx = await buildTx(kp, [ix]);
    const sig = await sendAndConfirm(tx, uuidv4(), `pause:${poolId}`, { redis });

    return { poolId, tx: sig };
  });
}

export async function unpausePool(params: { user: any; poolId: string }) {
  const { user, poolId } = params;

  return lock.withLock(`unpause:${poolId}`, "unpause", async () => {
    const client = await SolanaClient.getInstance();

    const kp = await client.getUserKeypair(user);
    const program = await client.getProgramForUser(user);
    const pk = kp.publicKey;

    const poolPk = new PublicKey(poolId);
    const [partsPda] = deriveParticipantsPda(poolPk);

    const ix = await program.methods
      .unpausePool()
      .accounts({
        pool: poolPk,
        user: pk,
        participants: partsPda,
      })
      .instruction();

    const tx = await buildTx(kp, [ix]);
    const sig = await sendAndConfirm(tx, uuidv4(), `unpause:${poolId}`, { redis });

    return { poolId, tx: sig };
  });
}

export async function forceExpire(params: { user: any; poolId: string }) {
  const { user, poolId } = params;

  return lock.withLock(`force-expire:${poolId}`, "force-expire", async () => {
    const client = await SolanaClient.getInstance();

    const kp = await client.getUserKeypair(user);
    const program = await client.getProgramForUser(user);
    const pk = kp.publicKey;

    const poolPk = new PublicKey(poolId);
    const [partsPda] = deriveParticipantsPda(poolPk);

    const ix = await program.methods
      .forceExpire()
      .accounts({
        pool: poolPk,
        user: pk,
        participants: partsPda,
      })
      .instruction();

    const tx = await buildTx(kp, [ix]);
    const sig = await sendAndConfirm(tx, uuidv4(), `force-expire:${poolId}`, { redis });

    return { poolId, tx: sig };
  });
}

/* ====================================================================================
   FINALIZE FORFEITED POOL  (dev-only, after rent delay)
==================================================================================== */
export async function finalizeForfeitedPool(params: { user: any; poolId: string }) {
  const { user, poolId } = params;

  return lock.withLock(`forfeit:${poolId}`, "finalize-forfeited-pool", async () => {
    const client = await SolanaClient.getInstance();

    const userKp = await client.getUserKeypair(user);
    const program = await client.getProgramForUser(user);
    const userPk = userKp.publicKey;

    const poolPk = new PublicKey(poolId);

    /* -------------------------------------------------------
       1️⃣ LOAD POOL FROM CHAIN
    -------------------------------------------------------- */
    const acc = await consensusRead(poolPk);
    if (!acc) throw new Error("Pool not found");

    const coder = client.getCoder();
    const rawPool: any = coder.decode("pool", acc.data);

    const mintPk = rawPool.mint;
    const devWallet = rawPool.devWallet as PublicKey;

    /* -------------------------------------------------------
       2️⃣ ONLY DEV WALLET CAN FINALIZE FORFEIT POOL
    -------------------------------------------------------- */
    if (!devWallet.equals(userPk)) {
      throw new Error("Only dev wallet can finalize forfeited pool");
    }

    /* -------------------------------------------------------
       3️⃣ PREP ACCOUNTS
    -------------------------------------------------------- */
    const poolToken = derivePoolTokenAddress(mintPk, poolPk);
    const treasuryPk = new PublicKey(rawPool.treasuryWallet);
    const treasuryToken = getAssociatedTokenAddressSync(mintPk, treasuryPk);

    /* -------------------------------------------------------
       4️⃣ BUILD INSTRUCTION
    -------------------------------------------------------- */
    const ix = await program.methods
      .finalizeForfeitedPool()
      .accounts({
        mint: mintPk,
        pool: poolPk,
        poolToken,
        treasuryToken,
        user: userPk,
        tokenProgram: anchor.utils.token.TOKEN_PROGRAM_ID,
        systemProgram: anchor.web3.SystemProgram.programId,
      })
      .instruction();

    /* -------------------------------------------------------
       5️⃣ SEND TX
    -------------------------------------------------------- */
    const tx = await buildTx(userKp, [ix]);
    const sig = await sendAndConfirm(
      tx,
      uuidv4(),
      `forfeit:${poolId}:${userPk.toBase58()}`,
      { redis }
    );

    /* -------------------------------------------------------
       6️⃣ DB UPDATE
    -------------------------------------------------------- */
    await prisma.pool.update({
      where: { id: poolId },
      data: {
        status: "forfeited",
        ended: true,
      },
    });

    return {
      poolId,
      tx: sig,
      treasury: treasuryPk.toBase58(),
    };
  });
}

export async function sweepExpiredPool(params: { user: any; poolId: string }) {
  const { user, poolId } = params;

  return lock.withLock(`sweep:${poolId}`, "sweep", async () => {
    const client = await SolanaClient.getInstance();

    const kp = await client.getUserKeypair(user);
    const program = await client.getProgramForUser(user);
    const pk = kp.publicKey;

    const poolPk = new PublicKey(poolId);

    const acc = await consensusRead(poolPk);
    if (!acc) throw new Error("Pool not found");

    const coder = client.getCoder();
    const raw: any = coder.decode("pool", acc.data);

    const mintPk = raw.mint;
    const poolToken = derivePoolTokenAddress(mintPk, poolPk);
    const [partsPda] = deriveParticipantsPda(poolPk);

    const ix = await program.methods
      .sweepExpiredPool()
      .accounts({
        mint: mintPk,
        pool: poolPk,
        poolToken,
        user: pk,
        tokenProgram: anchor.utils.token.TOKEN_PROGRAM_ID,
        participants: partsPda,
        systemProgram: anchor.web3.SystemProgram.programId,
      })
      .instruction();

    const tx = await buildTx(kp, [ix]);
    const sig = await sendAndConfirm(tx, uuidv4(), `sweep:${poolId}`, { redis });

    await prisma.pool.update({
      where: { id: poolId },
      data: { status: "expired", ended: true },
    });

    return { poolId, tx: sig };
  });
}

export async function adminClosePool(params: { user: any; poolId: string }) {
  const { user, poolId } = params;

  return lock.withLock(`admin-close:${poolId}`, "admin-close", async () => {
    const client = await SolanaClient.getInstance();

    const kp = await client.getUserKeypair(user);
    const program = await client.getProgramForUser(user);
    const pk = kp.publicKey;

    const poolPk = new PublicKey(poolId);

    const acc = await consensusRead(poolPk);
    const raw: any = client.getCoder().decode("pool", acc!.data);

    if (!raw.devWallet.equals(pk)) {
      throw new Error("Only dev wallet can close pool");
    }

    const mintPk = raw.mint;
    const poolToken = derivePoolTokenAddress(mintPk, poolPk);

    const ix = await program.methods
      .adminClosePool()
      .accounts({
        mint: mintPk,
        pool: poolPk,
        poolToken,
        creatorWallet: raw.creator,
        user: pk,
        tokenProgram: anchor.utils.token.TOKEN_PROGRAM_ID,
        systemProgram: anchor.web3.SystemProgram.programId,
      })
      .instruction();

    const tx = await buildTx(kp, [ix]);
    const sig = await sendAndConfirm(tx, uuidv4(), `admin-close:${poolId}`, { redis });

    await prisma.pool.update({
      where: { id: poolId },
      data: { status: "closed", ended: true },
    });

    return { poolId, tx: sig };
  });
}
