import * as anchor from "@coral-xyz/anchor";
import { PublicKey } from "@solana/web3.js";
import { consensusRead } from "../core/consensus";
import { SolanaClient } from "../client/solana-client";

/**
 * Validate that a given address is a valid Pool account.
 * This checks:
 *  - valid PublicKey
 *  - account exists
 *  - correct Anchor discriminator for "pool"
 */
export async function validatePoolAddressSimple(poolId: string) {
  let pk: PublicKey;

  // Validate public key format
  try {
    pk = new PublicKey(poolId);
  } catch {
    throw new Error("Invalid poolId format");
  }

  // Fetch on-chain account from consensus RPC
  const acc = await consensusRead(pk);
  if (!acc) {
    throw new Error("Pool account not found");
  }

  // Load Anchor coder and compute discriminator
  const client = await SolanaClient.getInstance();
  const coder = client.getCoder();

  const expected = anchor.utils.sha256.hash(`account:pool`).slice(0, 8);
  if (!expected) {
    throw new Error("Unable to compute pool discriminator");
  }

  // Take first 8 bytes from account data
  const actual = Buffer.from(acc.data.slice(0, 8)).toString("hex");

  if (actual !== expected) {
    throw new Error("Invalid pool account discriminator");
  }

  return true;
}
