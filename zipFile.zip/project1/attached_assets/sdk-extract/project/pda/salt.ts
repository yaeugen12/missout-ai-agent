export type Salt = Uint8Array & { __brand: "Salt" };

export function parseSalt(buf: Uint8Array): Salt {
  if (buf.length !== 32) {
    throw new Error(`Salt must be exactly 32 bytes, got ${buf.length}`);
  }
  return buf as Salt;
}

export function generateSalt(): Salt {
  const salt = crypto.getRandomValues(new Uint8Array(32));
  return parseSalt(salt);
}

export function saltFromHex(hex: string): Salt {
  const buf = Uint8Array.from(Buffer.from(hex, "hex"));
  return parseSalt(buf);
}
