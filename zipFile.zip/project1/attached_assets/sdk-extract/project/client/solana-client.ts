// src/solana/client/solana-client.ts

import * as anchor from "@coral-xyz/anchor";
import {
  Program,
  BorshAccountsCoder,
  Idl,
  AnchorProvider,
} from "@coral-xyz/anchor";

import {
  PublicKey,
  Keypair,
  Connection,
} from "@solana/web3.js";

import bs58 from "bs58";
import * as Sentry from "@sentry/node";
import { z } from "zod";

import prisma from "../../db";
import { keypairFromWalletRow, WalletRow } from "../../wallet";

import { IDL } from "../../types/missout_lottery";
import { PROGRAM_ID } from "../programs/program-id";

import { ensureHealthyConnection } from "../core/connection";
import { DistributedLock } from "../core/locks";
import { CacheManager } from "../core/cache";

import { PoolsClient } from "./pools-client";
import { RandomnessClient } from "./randomness-client";
import { RewardsClient } from "./rewards-client";

import { redis } from "../core/redis";

/* =====================================================================
   ENV VALIDATION
 ===================================================================== */
const ClientEnvSchema = z.object({
  SOLANA_CLUSTER: z.enum(["devnet", "testnet", "mainnet-beta"]).default("devnet"),
  SOLANA_RPC: z.string().url().optional(),
  SOLANA_RPC_FALLBACK: z.string().url().optional(),
  SOL_COMMITMENT: z.enum(["processed", "confirmed", "finalized"]).default("confirmed"),
  SOL_PREFLIGHT: z.enum(["processed", "confirmed", "finalized"]).default("confirmed"),
  SOL_MAX_RETRIES: z.coerce.number().int().min(0).default(3),

  SERVICE_WALLET_PRIVATE: z.string().min(1),
  SWITCHBOARD_PROGRAM_ID: z.string(),

  EXPECTED_POOL_VERSION: z.coerce.number().int().min(1).default(1),

  CACHE_TTL_MS: z.coerce.number().int().min(1000).default(30_000),
  LOCK_TTL_MS: z.coerce.number().int().min(1000).default(3000),
  HEARTBEAT_MS: z.coerce.number().int().min(500).default(1000),
});

type ClientEnv = z.infer<typeof ClientEnvSchema>;
const env: ClientEnv = ClientEnvSchema.parse(process.env);

/* =====================================================================
   SOLANA CLIENT
 ===================================================================== */
export class SolanaClient {
  private static instance: SolanaClient | null = null;
  private static initPromise: Promise<SolanaClient> | null = null;

  private connection!: Connection;
  private program!: Program<Idl>;
  private switchboardProgram: null = null;
  private coder!: BorshAccountsCoder;

  private cache = new CacheManager();
  private lock = new DistributedLock(redis, env.LOCK_TTL_MS, env.HEARTBEAT_MS);

  public pools!: PoolsClient;
  public randomness!: RandomnessClient;
  public rewards!: RewardsClient;

  private constructor(private deps: { prisma: typeof prisma }) {}

  /* ------------------------------------------------------------------ */
  static async getInstance(
    deps: { prisma: typeof prisma } = { prisma }
  ): Promise<SolanaClient> {
    if (this.instance) return this.instance;
    if (this.initPromise) return this.initPromise;

    this.initPromise = (async () => {
      const client = new SolanaClient(deps);
      await client.init();

      client.pools = new PoolsClient(client);
      client.randomness = new RandomnessClient(client);
      client.rewards = new RewardsClient(client);

      this.instance = client;
      return client;
    })();

    return this.initPromise;
  }

  /* =====================================================================
     INIT CONNECTION + PROGRAMS
   ===================================================================== */
  private async init(): Promise<void> {
    this.connection = await ensureHealthyConnection({});

    const serviceKp = this.getServiceKeypair();
    const serviceWallet = new anchor.Wallet(serviceKp);

    const provider = new AnchorProvider(this.connection, serviceWallet, {
      commitment: env.SOL_COMMITMENT,
      preflightCommitment: env.SOL_PREFLIGHT,
      maxRetries: env.SOL_MAX_RETRIES,
    });

    anchor.setProvider(provider);

    const idlPatched = JSON.parse(JSON.stringify(IDL));
    idlPatched.metadata = { address: PROGRAM_ID.toBase58() };

    this.program = new Program(idlPatched as Idl, provider);
    this.coder = new BorshAccountsCoder(idlPatched);

    // 🔥 IMPORTANT — Switchboard Anchor program disabled
    this.switchboardProgram = null;

    if (process.env.SENTRY_DSN && !Sentry.isInitialized()) {
      Sentry.init({ dsn: process.env.SENTRY_DSN });
    }
  }

  /* =====================================================================
     BASIC ACCESSORS
   ===================================================================== */
  getConnection() {
    return this.connection;
  }

  getProgram() {
    return this.program;
  }

  getSwitchboardProgram() {
    return null;
  }

  getCoder() {
    return this.coder;
  }

  getDevPubkey() {
    return this.getServiceKeypair().publicKey;
  }

  /* =====================================================================
     LOAD POOL STATE (FIXED)
   ===================================================================== */
  async getPoolState(poolId: string) {
    try {
      const pubkey = new PublicKey(poolId);
      const acc = await this.connection.getAccountInfo(pubkey);

      if (!acc) return null;

      // ⛔ Prevent decoding randomness (or any non-pool) account
      if (!acc.owner.equals(PROGRAM_ID)) {
        console.warn(
          `[SolanaClient] getPoolState called on NON-pool account: ${pubkey.toBase58()} | Owner=${acc.owner.toBase58()}`
        );
        return null;
      }

      return this.coder.decode("pool", acc.data);

    } catch (err) {
      console.error("getPoolState error:", err);
      return null;
    }
  }

  /* =====================================================================
     USER KEYPAIR LOADER
   ===================================================================== */
  async getUserKeypair(user: any): Promise<Keypair> {
    const tg = Number(user.tgId);

    const wallet = await this.deps.prisma.wallet.findFirst({
      where: { userId: BigInt(tg), isDefault: true }
    });

    if (!wallet) throw new Error(`User ${tg} has no default wallet`);

    return keypairFromWalletRow(wallet as WalletRow);
  }

  /* =====================================================================
     CUSTOM PROVIDERS
   ===================================================================== */
  createProvider(kp: Keypair): AnchorProvider {
    return new AnchorProvider(
      this.connection,
      new anchor.Wallet(kp),
      {
        commitment: env.SOL_COMMITMENT,
        preflightCommitment: env.SOL_PREFLIGHT,
        maxRetries: env.SOL_MAX_RETRIES,
      }
    );
  }

  async getProgramForUser(user: any): Promise<Program> {
    const kp = await this.getUserKeypair(user);
    const provider = this.createProvider(kp);

    const idlPatched = JSON.parse(JSON.stringify(IDL));
    idlPatched.metadata = { address: PROGRAM_ID.toBase58() };

    return new Program(idlPatched as Idl, provider);
  }

  /* =====================================================================
     SERVICE WALLET
   ===================================================================== */
  getServiceKeypair(): Keypair {
    const raw = env.SERVICE_WALLET_PRIVATE;
    if (!raw) throw new Error("SERVICE_WALLET_PRIVATE is missing from ENV!");

    let decoded: Uint8Array;
    try {
      decoded = bs58.decode(raw);
    } catch (e) {
      throw new Error("SERVICE_WALLET_PRIVATE is invalid base58: " + e);
    }

    if (decoded.length === 32) {
      throw new Error(
        "SERVICE_WALLET_PRIVATE is only 32 bytes — this is PUBLIC KEY, not secret key!"
      );
    }

    if (decoded.length !== 64) {
      throw new Error(
        `SERVICE_WALLET_PRIVATE must be 64 bytes. Received: ${decoded.length}`
      );
    }

    return Keypair.fromSecretKey(decoded);
  }

  /* =====================================================================
     SERVICE PROGRAM PROVIDER (ANCHOR)
   ===================================================================== */
  getServiceProgram() {
    const kp = this.getServiceKeypair();
    const provider = this.createProvider(kp);

    const idlPatched = JSON.parse(JSON.stringify(IDL));
    idlPatched.metadata = { address: PROGRAM_ID.toBase58() };

    return new Program(idlPatched as Idl, provider);
  }
}
