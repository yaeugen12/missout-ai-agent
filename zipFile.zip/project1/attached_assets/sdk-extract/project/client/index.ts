import { SolanaClient } from "./solana-client";

let client: SolanaClient | null = null;
let initializing: Promise<SolanaClient> | null = null;

/**
 * Thread-safe lazy singleton resolver
 */
export async function getSolanaClient(): Promise<SolanaClient> {
  // Already initialized → return directly
  if (client) return client;

  // Initialization already running → wait for it
  if (initializing) return initializing;

  // First caller triggers initialization
  initializing = (async () => {
    const instance = await SolanaClient.getInstance();
    client = instance;
    initializing = null; // release lock
    return instance;
  })();

  return initializing;
}

export default getSolanaClient;
