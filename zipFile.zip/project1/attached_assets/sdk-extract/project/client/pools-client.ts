// src/solana/client/pools-client.ts
import { PublicKey } from "@solana/web3.js";
import { SolanaClient } from "./solana-client";

import {
  createPool,
  joinPool,
  donate as donateService,
  cancelPool as cancelPoolService,
  claimRefund as claimRefundService,
  adminClosePool as adminClosePoolService,
  sweepExpiredPool as sweepExpiredPoolService,
  claimRent as claimRentService,
  forceExpire as forceExpireService,
  finalizeForfeitedPool as finalizeForfeitedPoolService,
  pausePool as pausePoolService,
  unpausePool as unpausePoolService,
} from "../services/pool-service";

import {
  unlockPoolForService,
  requestRandomnessForPool,
  payoutWinnerForService,
  createRandomnessAccountForPool,
} from "../services/randomness-service";


export class PoolsClient {
  constructor(private client: SolanaClient) {}

  private validatePoolId(poolId: string) {
    try {
      new PublicKey(poolId);
    } catch {
      throw new Error(`Invalid poolId: ${poolId}`);
    }
  }

  // ---------------------------------------------------------
  // GET / SYNC CHAIN STATE
  // ---------------------------------------------------------
  async getPoolState(poolId: string) {
    this.validatePoolId(poolId);
    return this.client.getPoolState(poolId);
  }

  async syncPoolState(poolId: string) {
    this.validatePoolId(poolId);
    return this.client.getPoolState(poolId);
  }

  // ---------------------------------------------------------
  // CREATE POOL
  // ---------------------------------------------------------
  async createPool(params: any) {
    return createPool(params);
  }

  // ---------------------------------------------------------
  // PARTICIPATION
  // ---------------------------------------------------------
  async joinPool(params: any) {
    this.validatePoolId(params.poolId);
    return joinPool(params);
  }

  async donate(params: any) {
    this.validatePoolId(params.poolId);
    return donateService(params);
  }

  async cancelPool(params: any) {
    this.validatePoolId(params.poolId);
    return cancelPoolService(params);
  }

  async claimRefund(params: any) {
    this.validatePoolId(params.poolId);
    return claimRefundService(params);
  }

  // ---------------------------------------------------------
  // ADMIN / DEV OPERATIONS
  // ---------------------------------------------------------
  async adminClosePool(params: any) {
    this.validatePoolId(params.poolId);
    return adminClosePoolService(params);
  }

  async sweepExpiredPool(params: any) {
    this.validatePoolId(params.poolId);
    return sweepExpiredPoolService(params);
  }

  async forceExpire(params: any) {
    this.validatePoolId(params.poolId);
    return forceExpireService(params);
  }

  async finalizeForfeitedPool(params: any) {
    this.validatePoolId(params.poolId);
    return finalizeForfeitedPoolService(params);
  }

  async claimRent(params: any) {
    this.validatePoolId(params.poolId);
    return claimRentService(params);
  }

  async pausePool(params: any) {
    this.validatePoolId(params.poolId);
    return pausePoolService(params);
  }

  async unpausePool(params: any) {
    this.validatePoolId(params.poolId);
    return unpausePoolService(params);
  }

  // ---------------------------------------------------------
  // RANDOMNESS (SERVICE WALLET ONLY)
  // ---------------------------------------------------------

  async createRandomnessAccount(poolId: string) {
    this.validatePoolId(poolId);
    return createRandomnessAccountForPool(poolId);
  }

  async unlockPool(poolId: string) {
    this.validatePoolId(poolId);
    return unlockPoolForService(poolId);
  }

  async requestRandomness(poolId: string, randomnessAccount: string) {
    this.validatePoolId(poolId);
    return requestRandomnessForPool(poolId, randomnessAccount);
  }

  async payoutWinner(poolId: string, randomnessAccount: string) {
    this.validatePoolId(poolId);
    return payoutWinnerForService(poolId);
  }
}
