import { SolanaClient } from "./solana-client";
import { claimReferralRewards } from "../services/rewards-service";
export class RewardsClient {
  constructor(private client: SolanaClient) {}
  async claimReferralRewards(user: any) {
    return claimReferralRewards(user);
  }
}