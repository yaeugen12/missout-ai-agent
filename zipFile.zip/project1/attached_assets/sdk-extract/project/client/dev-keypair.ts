// src/solana/utils/dev-keypair.ts

import bs58 from "bs58";
import { Keypair } from "@solana/web3.js";

/**
 * Service wallet (formerly dev wallet)
 * Used by:
 *  - pool monitor (unlock, randomness, payout)
 *  - service-side transactions
 */
export function getDevKeypair(): Keypair {
  const secret = process.env.SERVICE_WALLET_PRIVATE;

  if (!secret) {
    throw new Error("ENV SERVICE_WALLET_PRIVATE is missing!");
  }

  let decoded: Uint8Array;
  try {
    decoded = bs58.decode(secret);
  } catch (err) {
    throw new Error("SERVICE_WALLET_PRIVATE is not valid base58! " + err);
  }

  // Detect if user accidentally pasted the PUBLIC KEY instead of secret key
  if (decoded.length === 32) {
    throw new Error(
      "SERVICE_WALLET_PRIVATE is only 32 bytes — that is a PUBLIC KEY, not a secret key!"
    );
  }

  if (decoded.length !== 64) {
    throw new Error(
      `SERVICE_WALLET_PRIVATE must be a 64-byte secret key! Received ${decoded.length} bytes`
    );
  }

  return Keypair.fromSecretKey(decoded);
}
