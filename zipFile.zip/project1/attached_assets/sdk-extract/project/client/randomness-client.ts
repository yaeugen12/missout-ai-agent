// src/solana/client/randomness-client.ts
import { PublicKey } from "@solana/web3.js";
import { SolanaClient } from "./solana-client";

import {
  unlockPoolForService,
  requestRandomnessForPool,
  payoutWinnerForService,
  createRandomnessAccountForPool,
  selectWinnerForService,    // ⭐ NEW
} from "../services/randomness-service";

export class RandomnessClient {
  constructor(private client: SolanaClient) {}

  private validatePubkey(key: string | PublicKey, label: string) {
    try {
      if (key instanceof PublicKey) return;
      new PublicKey(key);
    } catch {
      throw new Error(`Invalid ${label}: ${key}`);
    }
  }

  // -------------------------------------------------------
  // UNLOCK POOL  (service wallet only)
  // -------------------------------------------------------
  async unlockPool(poolId: string) {
    this.validatePubkey(poolId, "poolId");
    return unlockPoolForService(poolId);
  }

  // -------------------------------------------------------
  // CREATE RANDOMNESS ACCOUNT  (service wallet only)
  // -------------------------------------------------------
  async createRandomnessAccount(poolId: string) {
    this.validatePubkey(poolId, "poolId");
    return createRandomnessAccountForPool(poolId);
  }

  // -------------------------------------------------------
  // REQUEST RANDOMNESS  (service wallet only)
  // -------------------------------------------------------
  async requestRandomness(poolId: string, randomnessAccount: string) {
    this.validatePubkey(poolId, "poolId");
    this.validatePubkey(randomnessAccount, "randomnessAccount");

    return requestRandomnessForPool(poolId, randomnessAccount);
  }

  // -------------------------------------------------------
  // SELECT WINNER  (service wallet only)
  // -------------------------------------------------------
  async selectWinner(poolId: string, randomnessAccount: string) {
    this.validatePubkey(poolId, "poolId");
    this.validatePubkey(randomnessAccount, "randomnessAccount");

    return selectWinnerForService(poolId, randomnessAccount);
  }

  // -------------------------------------------------------
  // PAYOUT WINNER  (service wallet only)
  // -------------------------------------------------------
  async payoutWinner(poolId: string, randomnessAccount: string) {
    this.validatePubkey(poolId, "poolId");
    this.validatePubkey(randomnessAccount, "randomnessAccount");

    return payoutWinnerForService(poolId);
  }
}
