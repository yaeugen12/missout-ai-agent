// src/constants/switchboard.ts
import { PublicKey } from "@solana/web3.js";

/**
 * Switchboard On-Demand **devnet** constants (the ones you posted)
 */
export const SB_ON_DEMAND_DEVNET_PID = new PublicKey(
  "Aio4gaXjXzJNVLtzwtNVmSqGKpANtXhybbkhtAC94ji2"
);
export const SB_ON_DEMAND_DEVNET_QUEUE = new PublicKey(
  "EYiAmGSdsQTuCw413V5BzaruWuCCSDgTPtBGvLkXHbe7"
);