import {
  Connection,
  clusterApiUrl,
  Commitment,
  Cluster,
} from "@solana/web3.js";

import * as Sentry from "@sentry/node";
import { z } from "zod";
import "dotenv/config";

import { SafeCircuitBreaker } from "./circuit-breaker";

/* ============================================================= */
/* 1. ENV VALIDATION */
/* ============================================================= */

const EnvSchema = z.object({
  SOLANA_CLUSTER: z.enum(["devnet", "testnet", "mainnet-beta"])
    .default("devnet"),

  SOLANA_RPC: z.string().optional(),
  SOLANA_RPC_FALLBACK: z.string().optional(),

  SOL_COMMITMENT: z.enum(["processed", "confirmed", "finalized"])
    .default("confirmed"),
  SOL_PREFLIGHT: z.enum(["processed", "confirmed", "finalized"])
    .default("confirmed"),

  SOL_MAX_RETRIES: z.coerce.number().int().min(0).default(3),
  REDIS_URL: z.string().default("redis://localhost:6379"),
});

type Env = z.infer<typeof EnvSchema>;
const env: Env = EnvSchema.parse(process.env);

/* ============================================================= */
/* 2. COMMITMENT CONFIG */
/* ============================================================= */

export const DEFAULT_COMMITMENT = {
  commitment: env.SOL_COMMITMENT as Commitment,
  preflightCommitment: env.SOL_PREFLIGHT as Commitment,
  maxRetries: env.SOL_MAX_RETRIES,
};

/* ============================================================= */
/* 3. RPC URL RESOLUTION */
/* ============================================================= */

function resolveRpc(primary?: string) {
  if (primary && primary.length > 5) return primary.trim();
  return clusterApiUrl(env.SOLANA_CLUSTER as Cluster);
}

export const PRIMARY_RPC = resolveRpc(env.SOLANA_RPC);
export const FALLBACK_RPC = env.SOLANA_RPC_FALLBACK?.trim() || "";

/* ============================================================= */
/* 4. CIRCUIT BREAKER */
/* ============================================================= */

export let breaker = new SafeCircuitBreaker({
  failureThreshold: 3,
  successThreshold: 1,
  timeoutMs: 4000,
  resetTimeoutMs: 8000,
});

/* ============================================================= */
/* 5. DEPENDENCY INJECTION */
/* ============================================================= */

export interface ConnectionDeps {
  createConnection: (url: string) => Connection;
  logger: Console;
  captureException: typeof Sentry.captureException;
  breaker: SafeCircuitBreaker;
}

export const defaultDeps: ConnectionDeps = {
  createConnection: (url) => new Connection(url, DEFAULT_COMMITMENT),
  logger: console,
  captureException: Sentry.captureException.bind(Sentry),
  breaker,
};

/* ============================================================= */
/* 6. SINGLETON STATE */
/* ============================================================= */

let _connection: Connection | null = null;
let _activePromise: Promise<Connection> | null = null;

/* ============================================================= */
/* 7. HANDSHAKE CHECK */
/* ============================================================= */

async function handshake(conn: Connection) {
  // Avoid triggering Helius 401 errors on fresh empty PDAs
  const { blockhash } = await conn.getLatestBlockhash();
  if (!blockhash) throw new Error("RPC returned empty blockhash");
}

/* ============================================================= */
/* 8. INIT CONNECTION */
/* ============================================================= */

async function initConnection(
  url: string,
  createConnection: (url: string) => Connection
): Promise<Connection> {
  const conn = createConnection(url);
  await handshake(conn);
  return conn;
}

/* ============================================================= */
/* 9. getConnection (with fallback & breaker) */
/* ============================================================= */

export async function getConnection(
  deps: Partial<ConnectionDeps> = {}
): Promise<Connection> {
  const {
    createConnection = defaultDeps.createConnection,
    logger = defaultDeps.logger,
    captureException = defaultDeps.captureException,
    breaker = defaultDeps.breaker,
  } = { ...defaultDeps, ...deps };

  if (_connection) return _connection;
  if (_activePromise) return _activePromise;

  _activePromise = (async () => {
    /* ------------------------- PRIMARY RPC ------------------------- */
    logger.log("[Solana] Connecting to PRIMARY RPC:", PRIMARY_RPC);

    try {
      const conn = await breaker.run(() =>
        initConnection(PRIMARY_RPC, createConnection)
      );
      logger.log("[Solana] PRIMARY RPC OK");
      _connection = conn;
      return conn;
    } catch (e) {
      logger.warn("[Solana] PRIMARY RPC failed:", (e as Error).message);
      captureException(e);
    }

    /* ------------------------ FALLBACK RPC ------------------------- */
    if (!FALLBACK_RPC) {
      throw new Error(
        `PRIMARY RPC failed (${PRIMARY_RPC}) and no SOLANA_RPC_FALLBACK configured.`
      );
    }

    logger.warn("[Solana] Trying FALLBACK RPC:", FALLBACK_RPC);

    try {
      const fallback = await breaker.run(() =>
        initConnection(FALLBACK_RPC, createConnection)
      );
      logger.log("[Solana] FALLBACK RPC OK");
      _connection = fallback;
      return fallback;
    } catch (e) {
      logger.error("[Solana] FALLBACK RPC failed:", (e as Error).message);
      captureException(e);
    }

    /* --------------------- TOTAL FAILURE ------------------------ */
    throw new Error(
      `❌ BOTH PRIMARY (${PRIMARY_RPC}) AND FALLBACK (${FALLBACK_RPC}) RPC failed`
    );
  })();

  return _activePromise.finally(() => {
    _activePromise = null;
  });
}

/* ============================================================= */
/* 10. ensureHealthyConnection */
/* ============================================================= */

export async function ensureHealthyConnection(
  deps: Partial<ConnectionDeps> = {}
): Promise<Connection> {
  try {
    const conn = await getConnection(deps);
    await handshake(conn);
    return conn;
  } catch {
    return resetConnection(deps);
  }
}

/* ============================================================= */
/* 11. RESET CONNECTION */
/* ============================================================= */

export async function resetConnection(
  deps: Partial<ConnectionDeps> = {}
): Promise<Connection> {
  console.log("[Solana] RESETTING connection…");

  // Replace breaker
  breaker = new SafeCircuitBreaker({
    failureThreshold: 3,
    successThreshold: 1,
    timeoutMs: 3000,
    resetTimeoutMs: 8000,
  });

  defaultDeps.breaker = breaker;
  deps.breaker = breaker;

  _connection = null;
  _activePromise = null;

  const conn = await getConnection({ ...defaultDeps, ...deps });

  console.log("[Solana] RESET complete — connection OK");
  return conn;
}
