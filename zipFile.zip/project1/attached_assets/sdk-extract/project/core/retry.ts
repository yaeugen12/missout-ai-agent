// src/core/retry.ts

import { SolanaCoreDeps } from "./tx";
import { defaultDeps } from "./tx";

/**
 * Generic retry handler with circuit breaker support.
 */
export async function retryAsync<T>(
  fn: () => Promise<T>,
  opts: {
    retries?: number;
    baseDelayMs?: number;
    deps?: Partial<SolanaCoreDeps>;
  } = {}
): Promise<T> {
  const { retries = 5, baseDelayMs = 200, deps = {} } = opts;

  const { captureException, logger, breaker } = {
    ...defaultDeps,
    ...deps,
  };

  let lastError: any = null;

  for (let i = 0; i < retries; i++) {
    try {
      // SafeCircuitBreaker.run waits for fn()
      return await breaker.run(async () => {
        return await fn();
      });

    } catch (e: any) {
      lastError = e;

      captureException(e);

      if (i < retries - 1) {
        const delay =
          baseDelayMs * 2 ** i + Math.random() * 150;

        logger.warn(
          `Retry ${i + 1}/${retries} after ${delay.toFixed(0)}ms`,
          e.message
        );

        await new Promise((r) => setTimeout(r, delay));
      }
    }
  }

  throw lastError;
}
