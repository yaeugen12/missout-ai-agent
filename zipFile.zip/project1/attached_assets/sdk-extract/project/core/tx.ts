// src/core/tx.ts  — PARTEA 1 / 2

import * as anchor from "@coral-xyz/anchor";
import {
  Connection,
  Keypair,
  PublicKey,
  TransactionInstruction,
  VersionedTransaction,
  TransactionMessage,
  ComputeBudgetProgram,
  AddressLookupTableAccount,
} from "@solana/web3.js";

import {
  createAssociatedTokenAccountInstruction,
  getAssociatedTokenAddressSync,
  TOKEN_PROGRAM_ID,
} from "@solana/spl-token";

import { v4 as uuidv4 } from "uuid";
import { z } from "zod";
import * as Sentry from "@sentry/node";

// RPC core
import {
  ensureHealthyConnection,
  ConnectionDeps,
  defaultDeps as connDefaultDeps,
  breaker,
} from "./connection";

import { SolanaError } from "./errors";
import { IdempotencyManager } from "./idempotency";
import { redis, type RedisClientType } from "./redis";

// Logging / parsing
import { extractLogsFromRpcError } from "./events/logs-extract";
import {
  parseProgramErrorFromLogs,
  ProgramError,
} from "../utils/errors";

import { parseEventsFromLogs } from "./events/event-parser";
import { SolanaClient } from "../client/solana-client";


// ──────────────────────────────────────────────────────────────
// 1. ENV
// ──────────────────────────────────────────────────────────────

const CoreEnvSchema = z.object({
  PRIORITY_FEE_MICROLAMPORTS: z.coerce.number().int().min(0).default(0),
  BATCH_SIZE: z.coerce.number().int().min(1).max(200).default(50),
  TX_CONFIRM_TIMEOUT_MS: z.coerce.number().int().min(2000).default(60_000),
  IDEMPOTENCY_TTL_SEC: z.coerce.number().int().min(600).default(86400),
  NONCE_TTL_SEC: z.coerce.number().int().min(300).default(7200),
});

type CoreEnv = z.infer<typeof CoreEnvSchema>;

const env: CoreEnv = CoreEnvSchema.parse({
  PRIORITY_FEE_MICROLAMPORTS: process.env.SOL_PRIORITY_FEE_U64,
  BATCH_SIZE: process.env.SOL_BATCH_SIZE,
  TX_CONFIRM_TIMEOUT_MS: process.env.SOL_TX_CONFIRM_TIMEOUT_MS,
  IDEMPOTENCY_TTL_SEC: process.env.SOL_IDEMPOTENCY_TTL_SEC,
  NONCE_TTL_SEC: process.env.SOL_NONCE_TTL_SEC,
});

// ──────────────────────────────────────────────────────────────
// 2. DEPENDENCIES
// ──────────────────────────────────────────────────────────────

export interface SolanaCoreDeps extends ConnectionDeps {
  redis: RedisClientType;
  captureException: typeof Sentry.captureException;
  logger: Console;
  uuidv4: () => string;
  now: () => number;
  breaker: typeof breaker;
}

export const defaultDeps: SolanaCoreDeps = {
  ...connDefaultDeps,
  captureException: Sentry.captureException.bind(Sentry),
  logger: console,
  uuidv4,
  now: () => Date.now(),
  redis,
  breaker,
};

// ──────────────────────────────────────────────────────────────
// 3. BATCH RPC HELPERS
// ──────────────────────────────────────────────────────────────

async function batchRpc<T>(
  items: PublicKey[],
  rpcCall: (batch: PublicKey[]) => Promise<T[]>,
  batchSize: number,
  deps: SolanaCoreDeps
): Promise<T[]> {
  const results: T[] = [];

  for (let i = 0; i < items.length; i += batchSize) {
    const batch = items.slice(i, i + batchSize);

    const batchResults = await deps.breaker.run(() => rpcCall(batch));

    results.push(...batchResults);
  }

  return results;
}

export async function batchGetAccounts(
  pubkeys: PublicKey[],
  deps: Partial<SolanaCoreDeps> = {}
): Promise<(any | null)[]> {
  const merged = { ...defaultDeps, ...deps } as SolanaCoreDeps;
  const conn = await ensureHealthyConnection(merged);

  return batchRpc(
    pubkeys,
    conn.getMultipleAccountsInfo.bind(conn),
    env.BATCH_SIZE,
    merged
  );
}

// ──────────────────────────────────────────────────────────────
// 4. BATCH — CREATE ATA IF MISSING
// ──────────────────────────────────────────────────────────────

export async function batchEnsureAtaIxs(
  owners: PublicKey[],
  mint: PublicKey,
  payer: PublicKey = owners[0],
  deps: Partial<SolanaCoreDeps> = {}
): Promise<TransactionInstruction[]> {
  const merged = { ...defaultDeps, ...deps } as SolanaCoreDeps;

  const atas = owners.map((o) => getAssociatedTokenAddressSync(mint, o));
  const infos = await batchGetAccounts(atas, merged);

  const ixs: TransactionInstruction[] = [];

  infos.forEach((acc, i) => {
    if (!acc) {
      ixs.push(
        createAssociatedTokenAccountInstruction(
          payer,
          atas[i],
          owners[i],
          mint
        )
      );
    }
  });

  return ixs;
}

// ──────────────────────────────────────────────────────────────
// 5. VALIDATE ATA (creates if missing)
// ──────────────────────────────────────────────────────────────

export async function validateATA(
  ata: PublicKey,
  owner: PublicKey,
  mint: PublicKey,
  signer: Keypair,
  deps: Partial<SolanaCoreDeps> = {}
): Promise<void> {
  const merged = { ...defaultDeps, ...deps } as SolanaCoreDeps;
  const conn = await ensureHealthyConnection(merged);

  const info = await conn.getAccountInfo(ata);

  if (info) {
    if (!info.owner.equals(TOKEN_PROGRAM_ID)) {
      throw new SolanaError("ATA owner mismatch", {
        ata: ata.toBase58(),
      });
    }
    return;
  }

  merged.logger.log(
    `[ATA] Creating missing: owner=${owner.toBase58()} mint=${mint.toBase58()}`
  );

  const ix = createAssociatedTokenAccountInstruction(
    signer.publicKey,
    ata,
    owner,
    mint
  );

  const tx = await buildTx(signer, [ix], { deps: merged });
  const nonce = merged.uuidv4();

  await sendAndConfirm(tx, nonce, undefined, merged);
}

// ──────────────────────────────────────────────────────────────
// 6. TX BUILDER
// ──────────────────────────────────────────────────────────────
export interface BuildTxOptions {
  priorityFeeMicroLamports?: number;
  lookupTables?: AddressLookupTableAccount[];
  deps?: Partial<SolanaCoreDeps>;
  additionalSigners?: Keypair[];   // 👈 NEW
}

export async function buildTx(
  payer: Keypair | { publicKey: PublicKey; secretKey: Uint8Array },
  instructions: TransactionInstruction[],
  opts: BuildTxOptions = {}
): Promise<VersionedTransaction> {
  const {
    priorityFeeMicroLamports = env.PRIORITY_FEE_MICROLAMPORTS,
    lookupTables = [],
    deps = {},
    additionalSigners = [],            // 👈 NEW
  } = opts;

  const merged = { ...defaultDeps, ...deps } as SolanaCoreDeps;
  const conn = await ensureHealthyConnection(merged);

  const kp =
    payer instanceof Keypair ? payer : Keypair.fromSecretKey(payer.secretKey);

  const { blockhash, lastValidBlockHeight } =
    await conn.getLatestBlockhash("confirmed");

  const ixs = [...instructions];

  if (priorityFeeMicroLamports > 0) {
    ixs.push(
      ComputeBudgetProgram.setComputeUnitPrice({
        microLamports: priorityFeeMicroLamports,
      })
    );
  }

  const message = new TransactionMessage({
    payerKey: kp.publicKey,
    recentBlockhash: blockhash,
    instructions: ixs,
  }).compileToV0Message(lookupTables);

  const tx = new VersionedTransaction(message);

  // 👇 SIGN WITH ALL REQUIRED SIGNERS
  tx.sign([kp, ...additionalSigners]);

  Object.defineProperty(tx, "__meta", {
    value: {
      blockhash,
      lastValidBlockHeight,
      payer: kp.publicKey.toBase58(),
    },
    enumerable: false,
  });

  return tx;
}
 
export async function sendAndConfirm(
  tx: VersionedTransaction,
  nonce: string,
  idempotencyKey?: string,
  deps: Partial<SolanaCoreDeps> = {}
): Promise<string> {
  const merged = { ...defaultDeps, ...deps } as SolanaCoreDeps;

  const { redis, logger, captureException, now } = merged;

  const conn = await ensureHealthyConnection(merged);

  const nonceKey = `tx:nonce:${nonce}`;
  const idemManager = new IdempotencyManager(
    redis,
    env.IDEMPOTENCY_TTL_SEC
  );

  const idemKey = idempotencyKey ? `tx:idem:${idempotencyKey}` : null;

  // ──────────────────────────────────────────────
  //  (1) IDEMPOTENCY
  // ──────────────────────────────────────────────
  if (idemKey) {
    const ex = await idemManager.getResult(idemKey);

    // already completed successfully
    if (ex?.status === "success" && ex.txHash) {
      return ex.txHash;
    }

    // still running from another worker
    if (ex?.status === "pending") {
      await new Promise((r) => setTimeout(r, 1000));

      const updated = await idemManager.getResult(idemKey);
      if (updated?.status === "success") {
        return updated.txHash!;
      }
    }

    const ok = await idemManager.start(idemKey);
    if (!ok) {
      throw new SolanaError("Idempotency conflict", { idempotencyKey });
    }
  }

  // ──────────────────────────────────────────────
  //  (2) NONCE FENCING
  // ──────────────────────────────────────────────
  const nonceState = await redis.get(nonceKey);

  if (nonceState && nonceState !== "sent") {
    // previous attempt completed
    return nonceState;
  }

  if (nonceState === "sent") {
    // maybe blockhash expired → check existing signature
    try {
      const sig = tx.signatures[0].toString();

      const status = await conn.getSignatureStatus(sig, {
        searchTransactionHistory: true,
      });

      if (status?.value?.confirmationStatus === "confirmed") {
        await redis.set(nonceKey, sig, { EX: env.NONCE_TTL_SEC });

        if (idemKey) await idemManager.success(idemKey, sig);

        return sig;
      }
    } catch {}

    // retry by clearing nonce
    await redis.del(nonceKey);
  }

  // mark as sent
  await redis.set(nonceKey, "sent", { EX: env.NONCE_TTL_SEC });

  // ──────────────────────────────────────────────
  //  (3) SEND + CONFIRM
  // ──────────────────────────────────────────────
  let sig: string;

  try {
    sig = await conn.sendTransaction(tx, {
      maxRetries: 3,
      skipPreflight: false,
      preflightCommitment: "processed",
    });

    const meta = (tx as any).__meta;
    const confirmStart = now();

    await conn.confirmTransaction(
      {
        signature: sig,
        blockhash: meta.blockhash,
        lastValidBlockHeight: meta.lastValidBlockHeight,
      },
      "confirmed"
    );

    if (now() - confirmStart > env.TX_CONFIRM_TIMEOUT_MS) {
      throw new SolanaError("Confirmation timeout", { sig });
    }

    // store success
    await redis.set(nonceKey, sig, { EX: env.NONCE_TTL_SEC });
    if (idemKey) await idemManager.success(idemKey, sig);

    return sig;
  } catch (err: any) {
    // remove nonce state
    await redis.del(nonceKey);

    if (idemKey) {
      await redis.set(
        idemKey,
        JSON.stringify({
          status: "error",
          message: err.message,
        }),
        { EX: env.IDEMPOTENCY_TTL_SEC }
      );
    }

    // ──────────────────────────────────────────────
    //   (4) LOG EXTRACTION
    // ──────────────────────────────────────────────
    const logs = extractLogsFromRpcError(err);

    if (!logs || logs.length === 0) {
      logger.error("TX failed (no logs)", err);
      captureException(err);
      throw new SolanaError("Transaction failed", {}, err);
    }

    // ──────────────────────────────────────────────
    //   (5) PARSE PROGRAM ERROR
    // ──────────────────────────────────────────────
    const programErr = parseProgramErrorFromLogs(logs);
    if (programErr) {
      logger.error("ProgramError:", programErr);
      captureException(programErr);
      throw programErr;
    }

    // ──────────────────────────────────────────────
    //   (6) PARSE EVENTS — but ignore errors
    // ──────────────────────────────────────────────
    try {
      const client = await SolanaClient.getInstance();
      const ev = parseEventsFromLogs(logs, client.getProgram());
      if (ev?.length) err.events = ev;
    } catch (e) {
      logger.warn("Event parse failed (ignored)", e);
    }

    // final log
    logger.error("TX failed", err);
    captureException(err);

    throw new SolanaError("Transaction failed", {}, err);
  }
}

// ──────────────────────────────────────────────────────────────
// Export ENV for external use
// ──────────────────────────────────────────────────────────────

export { env as SOLANA_CORE_ENV };