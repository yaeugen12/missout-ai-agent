import { RedisClientType } from "redis";
import { acquireLock, releaseLock, checkFencing } from "./redis-locks";

/**
 * Robust distributed lock with fencing tokens.
 * Compatible with the redis-locks implementation.
 */
export class DistributedLock {
  constructor(
    private redis: RedisClientType,
    private ttlMs: number,
    private heartbeatMs: number
  ) {}

  private lockKey(key: string, op: string) {
    return `lock:${key}:${op}`;
  }

  /** Try to acquire lock → returns fencing token or null */
  async acquire(key: string, op: string): Promise<{ token: number } | null> {
    const lkey = this.lockKey(key, op);
    const token = Date.now(); // fencing token

    const ok = await acquireLock(this.redis, lkey, token, this.ttlMs);
    return ok ? { token } : null;
  }

  /** Release lock safely */
  async release(key: string, op: string, token: number): Promise<void> {
    const lkey = this.lockKey(key, op);
    const cur = await this.redis.get(lkey);

    if (cur === String(token)) {
      await releaseLock(this.redis, lkey, token);
    }
  }

  /** Check fencing (lock freshness) */
  async check(key: string, op: string, token: number): Promise<boolean> {
    const lkey = this.lockKey(key, op);
    return checkFencing(this.redis, lkey, token);
  }

  /**
   * Run operation inside a distributed lock with retries,
   * fencing protection, and automatic heartbeat renewal.
   */
  async withLock<T>(
    key: string,
    op: string,
    fn: (token: number) => Promise<T>
  ): Promise<T> {
    for (let attempt = 0; attempt < 5; attempt++) {
      const lock = await this.acquire(key, op);

      if (!lock) {
        // exponential backoff
        await new Promise((r) =>
          setTimeout(r, 200 * 2 ** attempt + 50)
        );
        continue;
      }

      const token = lock.token;

      // heartbeat extends TTL but does NOT re-acquire lock
      const heartbeat = setInterval(async () => {
        const cur = await this.redis.get(this.lockKey(key, op));
        if (cur === String(token)) {
          // refresh TTL only if we still own the lock
          await this.redis.pExpire(this.lockKey(key, op), this.ttlMs);
        }
      }, this.heartbeatMs);

      try {
        if (!(await this.check(key, op, token))) {
          throw new Error("Stale lock (pre-check)");
        }

        const result = await fn(token);

        if (!(await this.check(key, op, token))) {
          throw new Error("Stale lock (post-check)");
        }

        return result;
      } finally {
        clearInterval(heartbeat);
        await this.release(key, op, token);
      }
    }

    throw new Error("Failed to acquire distributed lock");
  }
}
