import { PublicKey, Connection, AccountInfo } from "@solana/web3.js";

const RPC_TIMEOUT_MS = 4000;

function withTimeout<T>(p: Promise<T>, ms: number): Promise<T> {
  return new Promise((resolve, reject) => {
    const t = setTimeout(() => reject(new Error("RPC TIMEOUT")), ms);
    p.then(v => {
      clearTimeout(t);
      resolve(v);
    }).catch(err => {
      clearTimeout(t);
      reject(err);
    });
  });
}

type RpcSuccess = {
  ok: true;
  res: AccountInfo<Buffer>;
  source: number;
};

type RpcFailure = {
  ok: false;
  err: any;
  source: number;
};

function isRpcSuccess(r: RpcSuccess | RpcFailure): r is RpcSuccess {
  return r.ok === true && r.res !== null;
}

export async function consensusRead(pubkey: PublicKey): Promise<AccountInfo<Buffer>> {

  // ALWAYS fresh connection for consensus
  const rpcUrl = process.env.SOLANA_RPC!;
  const primary = new Connection(rpcUrl, { commitment: "processed" });

  const sources: Connection[] = [primary];

  const fallbackUrl = process.env.SOLANA_RPC_FALLBACK;
  if (fallbackUrl?.trim()) {
    sources.push(new Connection(fallbackUrl, { commitment: "processed" }));
  }

  const tasks = sources.map((c, i) =>
    withTimeout(c.getAccountInfo(pubkey, "processed"), RPC_TIMEOUT_MS)
      .then(res => ({
        ok: true as const,
        res: res!,
        source: i,
      }))
      .catch(err => ({
        ok: false as const,
        err,
        source: i,
      }))
  );

  const results = await Promise.all(tasks);
  const valid = results.filter(isRpcSuccess).map(r => r.res);

  if (valid.length === 0) {
    throw new Error(`Consensus failed: account ${pubkey.toBase58()} not found`);
  }

  return valid[0]; // no length sorting needed
}
