export type CircuitState = "CLOSED" | "OPEN" | "HALF_OPEN";

interface BreakerOptions {
  failureThreshold: number;
  successThreshold: number;
  timeoutMs: number;
  resetTimeoutMs: number;
}

export class SafeCircuitBreaker {
  private failures = 0;
  private successes = 0;
  private state: CircuitState = "CLOSED";
  private nextTry = 0;

  constructor(private opts: BreakerOptions) {}

  getState() {
    return this.state;
  }

  async run<T>(fn: () => Promise<T>): Promise<T> {
    const now = Date.now();

    // ---- BLOCK if OPEN and not ready for half-open
    if (this.state === "OPEN") {
      if (now < this.nextTry) {
        throw new Error("CircuitBreaker: OPEN");
      }
      this.state = "HALF_OPEN";
    }

    try {
      const result = await this.runWithTimeout(fn, this.opts.timeoutMs);
      this.onSuccess();
      return result;
    } catch (err) {
      this.onFailure();
      throw err;
    }
  }

  private onSuccess() {
    if (this.state === "HALF_OPEN") {
      this.successes++;
      if (this.successes >= this.opts.successThreshold) {
        this.close();
      }
    } else {
      // keep successes clean in CLOSED
      this.successes = 0;
    }

    // success always resets failures
    this.failures = 0;
  }

  private onFailure() {
    this.failures++;

    if (this.state === "HALF_OPEN") {
      return this.open();
    }

    if (this.failures >= this.opts.failureThreshold) {
      this.open();
    }
  }

  private open() {
    this.state = "OPEN";
    this.nextTry = Date.now() + this.opts.resetTimeoutMs;
    this.failures = 0;
    this.successes = 0;
  }

  private close() {
    this.state = "CLOSED";
    this.failures = 0;
    this.successes = 0;
  }

  private runWithTimeout<T>(fn: () => Promise<T>, timeoutMs: number) {
    return new Promise<T>((resolve, reject) => {
      const t = setTimeout(() => reject(new Error("CircuitBreaker: TIMEOUT")), timeoutMs);

      fn()
        .then((r) => {
          clearTimeout(t);
          resolve(r);
        })
        .catch((e) => {
          clearTimeout(t);
          reject(e);
        });
    });
  }
}
