import { LRUCache } from "lru-cache";

export class CacheManager {
  private ttlMs = 30_000;

  private lru = new LRUCache<string, { data: any; expires: number }>({
    max: 1_000,
  });

  async getOrSet<T>(key: string, loader: () => Promise<T>): Promise<T> {
    const cached = this.lru.get(key);

    if (cached && cached.expires > Date.now()) {
      return cached.data as T;
    }

    const data = await loader();

    this.lru.set(key, {
      data,
      expires: Date.now() + this.ttlMs,
    });

    return data;
  }

  invalidate(key: string): void {
    this.lru.delete(key);
  }

  invalidatePrefix(prefix: string): void {
    for (const k of this.lru.keys()) {
      if (k.startsWith(prefix)) {
        this.lru.delete(k);
      }
    }
  }
}
