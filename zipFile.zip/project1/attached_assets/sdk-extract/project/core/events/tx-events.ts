import * as anchor from "@coral-xyz/anchor";
import { Connection } from "@solana/web3.js";

export async function parseTxEvents(
  signature: string,
  program: anchor.Program,
  conn: Connection
) {
  try {
    const tx = await conn.getTransaction(signature, {
      maxSupportedTransactionVersion: 0,
      commitment: "confirmed",
    });

    if (!tx || !tx.meta) return [];

    const logs: string[] = tx.meta.logMessages || [];

    if (logs.length === 0) return [];

    const parser = new anchor.EventParser(program.programId, program.coder);

    return [...parser.parseLogs(logs)];
  } catch (err) {
    console.error("parseTxEvents error:", err);
    return [];
  }
}
