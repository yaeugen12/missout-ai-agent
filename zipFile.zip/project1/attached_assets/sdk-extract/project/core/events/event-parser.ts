import * as anchor from "@coral-xyz/anchor";

export interface ParsedEvent {
  name: string;
  data: any;
  logIndex: number;
}

export function parseEventsFromLogs(
  logs: string[] | null | undefined,
  program: anchor.Program
): ParsedEvent[] {
  if (!logs || logs.length === 0) return [];

  try {
    const parser = new anchor.EventParser(program.programId, program.coder);

    // Anchor returns a generator → convert to array
    const parsed = [...parser.parseLogs(logs)];

    return parsed.map((evt, index) => ({
      name: evt.name,
      data: evt.data,
      logIndex: index,
    }));
  } catch (err) {
    // Prevent any crash if Anchor fails to parse logs
    console.error("Event parse error:", err);
    return [];
  }
}
