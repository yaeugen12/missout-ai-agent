export function extractLogsFromRpcError(err: any): string[] {
  if (!err) return [];

  // Direct log arrays
  if (Array.isArray(err.logs)) return err.logs;
  if (Array.isArray(err.context?.logs)) return err.context.logs;
  if (Array.isArray(err.context?.value?.logs)) return err.context.value.logs;
  if (Array.isArray(err.data?.logs)) return err.data.logs;

  // Anchor error wrapper
  if (Array.isArray(err.error?.logs)) return err.error.logs;

  // Solana "InstructionError" structures
  if (Array.isArray(err.transactionMessage?.logs)) {
    return err.transactionMessage.logs;
  }

  // Fallback 1: often errors contain text logs like:
  // "Program log: ...\nProgram log: ..."
  const text = String(err);

  const programLogMatches = text
    .split("\n")
    .filter((l) => l.includes("Program log:") || l.includes("Program data:"));

  if (programLogMatches.length > 0) {
    return programLogMatches.map((l) => l.trim());
  }

  // Fallback 2: sometimes Solana prints raw JSON inside error text
  const match = text.match(/logs":\s*(\[[^\]]*\])/);
  if (match) {
    try {
      const parsed = JSON.parse(match[1]);
      if (Array.isArray(parsed)) return parsed;
    } catch {}
  }

  return [];
}
