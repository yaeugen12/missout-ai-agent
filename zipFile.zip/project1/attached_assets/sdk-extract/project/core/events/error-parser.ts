// src/utils/error-parser.ts

export { ProgramError, parseProgramErrorFromLogs } from "../../utils/errors";
