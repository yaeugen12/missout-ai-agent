export class SolanaError extends Error {
  context?: Record<string, any>;
  logs?: string[];
  txSig?: string;
  original?: any;

  constructor(
    message: string,
    context: Record<string, any> = {},
    original?: any
  ) {
    super(message);

    // acceptă ORICE chei în context
    this.context = { ...context };

    if (original) {
      this.original = original;
      // daca exista logs sau txSig, le extragem
      if (original.logs) this.logs = original.logs;
      if (original.txSig) this.txSig = original.txSig;
    }
  }
}
