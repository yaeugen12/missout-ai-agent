// src/core/redis.ts
import { createClient, type RedisClientType } from "redis";
import { defaultDeps } from "./connection";

export type { RedisClientType }; // re-export tip pentru utilizare externă

export const redis: RedisClientType = createClient({
  url: process.env.REDIS_URL || "redis://localhost:6379",
});

// ------------------------------------------------------------
// LOGGING
// ------------------------------------------------------------

redis.on("error", (err) => {
  defaultDeps.logger.error("[Redis] connection error", err);
});

redis
  .connect()
  .then(() => {
    defaultDeps.logger.log("[Redis] connected");
  })
  .catch((err) => {
    defaultDeps.logger.error("[Redis] initial connect failed", err);
  });

export default redis;
