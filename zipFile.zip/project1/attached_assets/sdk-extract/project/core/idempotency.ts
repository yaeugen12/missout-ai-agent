import { RedisClientType } from "redis";

export type IdempotencyStatus = "pending" | "success" | "failed";

interface IdempotencyRecord {
  status: IdempotencyStatus;
  txHash?: string;
  error?: string;
}

export class IdempotencyManager {
  constructor(
    private redis: RedisClientType,
    private ttlSec: number
  ) {}

  /**
   * Try to claim an idempotency key.
   * Returns:
   *  - true  = current call should execute the operation
   *  - false = another worker already started this operation
   */
  async start(key: string): Promise<boolean> {
    const res = await this.redis.set(
      key,
      JSON.stringify({ status: "pending" }),
      {
        NX: true,
        EX: this.ttlSec,
      }
    );
    return res === "OK";
  }

  /** Mark operation as successful */
  async success(key: string, txHash: string): Promise<void> {
    await this.redis.set(
      key,
      JSON.stringify({
        status: "success",
        txHash,
      }),
      { EX: this.ttlSec }
    );
  }

  /** Mark operation as failed */
  async fail(key: string, error: string): Promise<void> {
    await this.redis.set(
      key,
      JSON.stringify({
        status: "failed",
        error,
      }),
      { EX: this.ttlSec }
    );
  }

  /** Load stored result */
  async getResult(key: string): Promise<IdempotencyRecord | null> {
    const raw = await this.redis.get(key);
    if (!raw) return null;

    try {
      return JSON.parse(raw);
    } catch {
      return null;
    }
  }
}
