import { RedisClientType } from "redis";

/**
 * Basic Redis lock helpers with fencing tokens.
 * All operations are atomic due to Redis guarantees.
 */

/** Acquire lock using SET NX PX */
export async function acquireLock(
  redis: RedisClientType,
  key: string,
  token: number,
  ttlMs: number
): Promise<boolean> {
  const res = await redis.set(key, token.toString(), {
    NX: true,
    PX: ttlMs,
  });

  return res === "OK";
}

/** Release lock ONLY if token matches */
export async function releaseLock(
  redis: RedisClientType,
  key: string,
  token: number
): Promise<void> {
  const current = await redis.get(key);
  if (current === String(token)) {
    await redis.del(key);
  }
}

/** Check fencing (token still valid) */
export async function checkFencing(
  redis: RedisClientType,
  key: string,
  token: number
): Promise<boolean> {
  const current = await redis.get(key);
  return current === String(token);
}
