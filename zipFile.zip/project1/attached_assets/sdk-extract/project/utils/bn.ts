import BN from "bn.js";

/**
 * Convert anything → bigint (safe & fast)
 */
export function toBigInt(
  value: BN | string | number | bigint | null | undefined
): bigint {
  if (value === null || value === undefined) return 0n;

  if (typeof value === "bigint") return value;
  if (typeof value === "number") return BigInt(Math.floor(value));
  if (typeof value === "string") return BigInt(value);

  // BN
  return BigInt(value.toString(10));
}

/**
 * Convert anything → number.
 * Safe: throws if bigint > MAX_SAFE_INTEGER.
 */
export function toNumber(
  value: BN | string | number | bigint | null | undefined
): number {
  if (value === null || value === undefined) return 0;

  if (typeof value === "number") return value;
  if (typeof value === "string") return Number(value);

  if (typeof value === "bigint") {
    if (value > BigInt(Number.MAX_SAFE_INTEGER)) {
      throw new Error(
        `BigInt too large to convert safely to number: ${value.toString()}`
      );
    }
    return Number(value);
  }

  // BN
  const num = value.toNumber();
  if (!Number.isSafeInteger(num)) {
    throw new Error(`BN too large to convert safely to number: ${value.toString()}`);
  }
  return num;
}

export const bnToBigInt = toBigInt;
export const bnToNumber = toNumber;
