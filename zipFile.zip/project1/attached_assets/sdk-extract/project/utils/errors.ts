// utils/errors.ts

export enum ProgramErrorCode {
  PoolExpired = 0,
  PoolNotExpired = 1,
  PoolNotEmpty = 2,
  NotCreator = 3,
  NotDeveloper = 4,
  Unauthorized = 5,
  AlreadyParticipated = 6,
  MaxParticipantsReached = 7,
  PoolClosed = 8,
  Overflow = 9,
  InvalidWinnerAccount = 10,
  InvalidParticipantToken = 11,
  InvalidMint = 12,
  MintHasMintAuthority = 13,
  MintHasFreezeAuthority = 14,
  InvalidDecimals = 15,
  ExcessiveFees = 16,
  InvalidParticipantCount = 17,
  InvalidRandomnessAccount = 18,
  RandomnessNotResolved = 19,
  NoParticipants = 20,
  InvalidPoolStatus = 21,
  RandomnessAlreadySet = 22,
  CannotDecreaseLockDuration = 23,
  RandomnessNotCommitted = 24,
  RandomnessNotRevealed = 25,
  InvalidRandomness = 26,
  TooManyParticipants = 27,
  InvalidParticipantRange = 28,
  InvalidAmount = 29,
  InvalidLockDuration = 30,
  PoolStillLocked = 31,
  InvalidParticipantsPda = 32,
  InsufficientFundsForBurn = 33,
  InvalidTokenProgram = 34,
  ZeroSupply = 35,
  SpoofedDonation = 36,
  InvalidWinnerPubkey = 37,
  InvalidWinnerTokenOwner = 38,
  ForbiddenExtension = 39,
  HasDelegate = 40,
  HasCloseAuthority = 41,
  Paused = 42,
  ConfigMismatch = 43,
  FrozenAccount = 44,
  InsufficientFunds = 45,
  UninitializedAccount = 46,
  RandomnessExpired = 47,
  AlreadyInitialized = 48,
  PoolUnavailableForJoin = 49,
  PoolLockedForJoin = 50,
  DustNotAllowed = 51,
  JoinClosedAfterUnlock = 52,
  DonateClosedAfterUnlock = 53,
  TooEarlyForEmergency = 54,
  NotParticipant = 55,
  AlreadyEnded = 56,
  CannotChangeAfterJoins = 57,
}

const ERROR_MESSAGES: Record<number, string> = {
  0: "Pool has expired",
  1: "Pool is not expired",
  2: "Pool still contains funds",
  3: "Only the pool creator may perform this action",
  4: "Only the dev wallet may perform this action",
  5: "Unauthorized action",
  6: "User already joined the pool",
  7: "Maximum participants reached",
  8: "Pool is closed",
  9: "Overflow",
  10: "Invalid winner account",
  11: "Invalid participant token",
  12: "Invalid mint",
  13: "Mint must have no mint authority",
  14: "Mint must have no freeze authority",
  15: "Token mint has unsupported decimals",
  16: "Total fee BPS exceeds allowed maximum",
  17: "Invalid participant count",
  18: "Invalid randomness account",
  19: "Randomness not resolved",
  20: "Pool has no participants",
  21: "Invalid pool status",
  22: "Randomness already assigned",
  23: "Lock duration cannot be decreased",
  24: "Randomness not committed",
  25: "Randomness not revealed",
  26: "Randomness data is invalid",
  27: "Too many participants",
  28: "Invalid participant range",
  29: "Invalid amount",
  30: "Invalid lock duration",
  31: "Pool still locked",
  32: "Invalid participants PDA",
  33: "Insufficient funds for burn",
  34: "Invalid token program",
  35: "Mint has zero supply",
  36: "Pool token balance mismatch",
  37: "Winner pubkey mismatch",
  38: "Winner token owner mismatch",
  39: "Token-2022 mint has forbidden extension",
  40: "ATA has delegate",
  41: "ATA has close authority",
  42: "Pool is paused",
  43: "Pool config hash mismatch",
  44: "Token account frozen",
  45: "Insufficient funds",
  46: "Uninitialized account",
  47: "Randomness expired",
  48: "Already initialized",
  49: "Pool unavailable for join",
  50: "Pool locked for join",
  51: "Dust not allowed",
  52: "Joining closed after unlock",
  53: "Donations closed after unlock",
  54: "Too early for emergency action",
  55: "User is not participant",
  56: "Pool already ended",
  57: "Cannot change lock duration after joins",
};

export class ProgramError extends Error {
  constructor(
    public code: ProgramErrorCode,
    public message: string,
    public logs?: string[]
  ) {
    super(message);
    this.name = "ProgramError";
  }
}

/**
 * Attempts to extract Anchor / Solana program error from logs.
 */
export function parseProgramErrorFromLogs(logs: string[]): ProgramError | null {
  if (!logs || logs.length === 0) return null;

  // Anchor form: "Error Code: PoolExpired"
  for (const log of logs) {
    const m = log.match(/Error Code: (\w+)/);
    if (m) {
      const name = m[1];
      const code = (ProgramErrorCode as any)[name];
      if (typeof code === "number") {
        return new ProgramError(code, ERROR_MESSAGES[code], logs);
      }
    }
  }

  // Raw BPF error: "custom program error: 0xNN"
  for (const log of logs) {
    const m = log.match(/custom program error: 0x([0-9a-f]+)/i);
    if (m) {
      const code = parseInt(m[1], 16);
      if (ERROR_MESSAGES[code]) {
        return new ProgramError(code as any, ERROR_MESSAGES[code], logs);
      }
    }
  }

  return null;
}
