import axios from "axios";
import { PublicKey } from "@solana/web3.js";
import { CacheManager } from "../core/cache";
import { retryAsync } from "../core/retry";
import { redis } from "../core/redis";

const cache = new CacheManager();

/* Stablecoins mint list → always 1 USD */
const STABLES = new Set<string>([
  // USDC
  "Es9vMFrzaCERzB5tGj7nJBDatAsM9H9NP7VDaRao7yH9",
  "7XSvodXKChxMFN42oE6QSPiR7Bnc6VNzigpGwZr7D7Hu", // devnet
  // USDT
  "BQcdqvQ5iCw3y1wFpXe5zjuY4xXHzkwmo7aXstixSeKc",
]);

/**
 * Get token USD price via Dexscreener
 * Uses:
 *  - in-memory cache (30s)
 *  - Redis cache (60s)
 *  - retry system
 */
export async function getTokenPriceInUSD(mint: PublicKey): Promise<number> {
  const mintStr = mint.toBase58();
  const redisKey = `price:${mintStr}`;

  // -------------------------------------------------------
  // 1. Stablecoins → instant price
  // -------------------------------------------------------
  if (STABLES.has(mintStr)) {
    return 1.0;
  }

  // -------------------------------------------------------
  // 2. In-memory cache (LRU)
  // -------------------------------------------------------
  return cache.getOrSet(redisKey, async () => {
    // ---------------------------------------------------
    // 3. Check Redis cache
    // ---------------------------------------------------
    const redisCached = await redis.get(redisKey);
    if (redisCached) {
      const val = parseFloat(redisCached);
      if (!isNaN(val)) return val;
    }

    // ---------------------------------------------------
    // 4. Fetch from Dexscreener with retry
    // ---------------------------------------------------
    const price = await retryAsync(async () => {
      const { data } = await axios.get(
        `https://api.dexscreener.com/latest/dex/tokens/${mintStr}`
      );

      const val = parseFloat(data?.pairs?.[0]?.priceUsd ?? "0");

      if (isNaN(val) || val <= 0) {
        throw new Error(`Invalid price from Dexscreener for ${mintStr}`);
      }

      return val;
    });

    // ---------------------------------------------------
    // 5. Cache in Redis for 60 seconds
    // ---------------------------------------------------
    await redis.set(redisKey, price.toString(), { EX: 60 });

    return price;
  });
}
