import { Idl } from "@coral-xyz/anchor";

// Define the ActionType enum
export enum ActionType {
  Created = "created",
  Joined = "joined",
  Donated = "donated",
  Closed = "closed",
  Ended = "ended",
  Cancelled = "cancelled",
  RandomnessCommitted = "randomnessCommitted",
  ReachedMax = "reachedMax",
  Error = "error", // Added error variant
}

// IDL content
export const IDL: Idl = {
  "address": "53oTPbfy559uTaJQAbuWeAN1TyWXK1KfxUsM2GPJtrJw",
    "metadata": {
      "name": "ml",
      "version": "0.1.0",
      "spec": "0.1.0"
    },
    "instructions": [
      {
        "name": "adminClosePool",
        "discriminator": [
          83,
          105,
          178,
          188,
          61,
          125,
          117,
          200
        ],
        "accounts": [
          {
            "name": "mint",
            "writable": true,
            "relations": [
              "pool"
            ]
          },
          {
            "name": "pool",
            "writable": true
          },
          {
            "name": "poolToken",
            "writable": true
          },
          {
            "name": "creatorWallet",
            "writable": true
          },
          {
            "name": "user",
            "writable": true,
            "signer": true
          },
          {
            "name": "tokenProgram",
            "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
          },
          {
            "name": "systemProgram",
            "address": "11111111111111111111111111111111"
          }
        ],
        "args": []
      },
      {
        "name": "cancelPool",
        "discriminator": [
          211,
          11,
          27,
          100,
          252,
          115,
          57,
          77
        ],
        "accounts": [
          {
            "name": "mint",
            "writable": true,
            "relations": [
              "pool"
            ]
          },
          {
            "name": "pool",
            "writable": true
          },
          {
            "name": "poolToken",
            "writable": true
          },
          {
            "name": "user",
            "writable": true,
            "signer": true
          },
          {
            "name": "tokenProgram",
            "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
          },
          {
            "name": "systemProgram",
            "address": "11111111111111111111111111111111"
          }
        ],
        "args": []
      },
      {
        "name": "claimRefund",
        "discriminator": [
          15,
          16,
          30,
          161,
          255,
          228,
          97,
          60
        ],
        "accounts": [
          {
            "name": "mint",
            "writable": true,
            "relations": [
              "pool"
            ]
          },
          {
            "name": "pool",
            "writable": true
          },
          {
            "name": "poolToken",
            "writable": true
          },
          {
            "name": "userToken",
            "writable": true
          },
          {
            "name": "treasuryToken",
            "writable": true
          },
          {
            "name": "user",
            "writable": true,
            "signer": true
          },
          {
            "name": "tokenProgram",
            "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
          },
          {
            "name": "participants",
            "writable": true,
            "pda": {
              "seeds": [
                {
                  "kind": "const",
                  "value": [
                    112,
                    97,
                    114,
                    116,
                    105,
                    99,
                    105,
                    112,
                    97,
                    110,
                    116,
                    115
                  ]
                },
                {
                  "kind": "account",
                  "path": "pool"
                }
              ]
            }
          }
        ],
        "args": []
      },
      {
        "name": "claimRent",
        "discriminator": [
          57,
          233,
          51,
          137,
          102,
          101,
          26,
          101
        ],
        "accounts": [
          {
            "name": "pool",
            "writable": true
          },
          {
            "name": "mint",
            "writable": true
          },
          {
            "name": "poolToken",
            "writable": true
          },
          {
            "name": "closeTarget",
            "writable": true
          },
          {
            "name": "user",
            "writable": true,
            "signer": true
          },
          {
            "name": "tokenProgram",
            "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
          },
          {
            "name": "participants",
            "writable": true,
            "pda": {
              "seeds": [
                {
                  "kind": "const",
                  "value": [
                    112,
                    97,
                    114,
                    116,
                    105,
                    99,
                    105,
                    112,
                    97,
                    110,
                    116,
                    115
                  ]
                },
                {
                  "kind": "account",
                  "path": "pool"
                }
              ]
            }
          }
        ],
        "args": []
      },
      {
        "name": "createPool",
        "discriminator": [
          233,
          146,
          209,
          142,
          207,
          104,
          64,
          188
        ],
        "accounts": [
          {
            "name": "mint",
            "writable": true
          },
          {
            "name": "pool",
            "writable": true,
            "pda": {
              "seeds": [
                {
                  "kind": "const",
                  "value": [
                    112,
                    111,
                    111,
                    108
                  ]
                },
                {
                  "kind": "account",
                  "path": "mint"
                },
                {
                  "kind": "arg",
                  "path": "salt"
                }
              ]
            }
          },
          {
            "name": "userToken",
            "writable": true
          },
          {
            "name": "user",
            "writable": true,
            "signer": true
          },
          {
            "name": "poolToken",
            "writable": true,
            "pda": {
              "seeds": [
                {
                  "kind": "account",
                  "path": "pool"
                },
                {
                  "kind": "account",
                  "path": "tokenProgram"
                },
                {
                  "kind": "account",
                  "path": "mint"
                }
              ],
              "program": {
                "kind": "const",
                "value": [
                  140,
                  151,
                  37,
                  143,
                  78,
                  36,
                  137,
                  241,
                  187,
                  61,
                  16,
                  41,
                  20,
                  142,
                  13,
                  131,
                  11,
                  90,
                  19,
                  153,
                  218,
                  255,
                  16,
                  132,
                  4,
                  142,
                  123,
                  216,
                  219,
                  233,
                  248,
                  89
                ]
              }
            }
          },
          {
            "name": "tokenProgram",
            "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
          },
          {
            "name": "associatedTokenProgram",
            "address": "ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL"
          },
          {
            "name": "systemProgram",
            "address": "11111111111111111111111111111111"
          },
          {
            "name": "rent",
            "address": "SysvarRent111111111111111111111111111111111"
          },
          {
            "name": "participants",
            "writable": true,
            "pda": {
              "seeds": [
                {
                  "kind": "const",
                  "value": [
                    112,
                    97,
                    114,
                    116,
                    105,
                    99,
                    105,
                    112,
                    97,
                    110,
                    116,
                    115
                  ]
                },
                {
                  "kind": "account",
                  "path": "pool"
                }
              ]
            }
          }
        ],
        "args": [
          {
            "name": "salt",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "maxParticipants",
            "type": "u8"
          },
          {
            "name": "lockDuration",
            "type": "i64"
          },
          {
            "name": "amount",
            "type": "u64"
          },
          {
            "name": "devWallet",
            "type": "pubkey"
          },
          {
            "name": "devFeeBps",
            "type": "u16"
          },
          {
            "name": "burnFeeBps",
            "type": "u16"
          },
          {
            "name": "treasuryWallet",
            "type": "pubkey"
          },
          {
            "name": "treasuryFeeBps",
            "type": "u16"
          },
          {
            "name": "allowMock",
            "type": "bool"
          }
        ]
      },
      {
        "name": "donate",
        "discriminator": [
          121,
          186,
          218,
          211,
          73,
          70,
          196,
          180
        ],
        "accounts": [
          {
            "name": "mint",
            "writable": true,
            "relations": [
              "pool"
            ]
          },
          {
            "name": "pool",
            "writable": true
          },
          {
            "name": "poolToken",
            "writable": true
          },
          {
            "name": "userToken",
            "writable": true
          },
          {
            "name": "user",
            "writable": true,
            "signer": true
          },
          {
            "name": "tokenProgram",
            "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
          },
          {
            "name": "participants",
            "pda": {
              "seeds": [
                {
                  "kind": "const",
                  "value": [
                    112,
                    97,
                    114,
                    116,
                    105,
                    99,
                    105,
                    112,
                    97,
                    110,
                    116,
                    115
                  ]
                },
                {
                  "kind": "account",
                  "path": "pool"
                }
              ]
            }
          }
        ],
        "args": [
          {
            "name": "amount",
            "type": "u64"
          }
        ]
      },
      {
        "name": "finalizeForfeitedPool",
        "discriminator": [
          193,
          214,
          137,
          120,
          249,
          9,
          59,
          161
        ],
        "accounts": [
          {
            "name": "mint",
            "writable": true,
            "relations": [
              "pool"
            ]
          },
          {
            "name": "pool",
            "writable": true
          },
          {
            "name": "poolToken",
            "writable": true
          },
          {
            "name": "treasuryToken",
            "docs": [
              "Treasury destination"
            ],
            "writable": true
          },
          {
            "name": "user",
            "writable": true,
            "signer": true
          },
          {
            "name": "tokenProgram",
            "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
          },
          {
            "name": "participants",
            "writable": true,
            "pda": {
              "seeds": [
                {
                  "kind": "const",
                  "value": [
                    112,
                    97,
                    114,
                    116,
                    105,
                    99,
                    105,
                    112,
                    97,
                    110,
                    116,
                    115
                  ]
                },
                {
                  "kind": "account",
                  "path": "pool"
                }
              ]
            }
          }
        ],
        "args": []
      },
      {
        "name": "forceExpire",
        "discriminator": [
          181,
          233,
          225,
          150,
          213,
          57,
          145,
          169
        ],
        "accounts": [
          {
            "name": "pool",
            "writable": true
          },
          {
            "name": "user",
            "signer": true
          }
        ],
        "args": []
      },
      {
        "name": "joinPool",
        "discriminator": [
          14,
          65,
          62,
          16,
          116,
          17,
          195,
          107
        ],
        "accounts": [
          {
            "name": "mint",
            "writable": true,
            "relations": [
              "pool"
            ]
          },
          {
            "name": "pool",
            "writable": true
          },
          {
            "name": "poolToken",
            "writable": true
          },
          {
            "name": "userToken",
            "writable": true
          },
          {
            "name": "user",
            "writable": true,
            "signer": true
          },
          {
            "name": "tokenProgram",
            "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
          },
          {
            "name": "participants",
            "writable": true,
            "pda": {
              "seeds": [
                {
                  "kind": "const",
                  "value": [
                    112,
                    97,
                    114,
                    116,
                    105,
                    99,
                    105,
                    112,
                    97,
                    110,
                    116,
                    115
                  ]
                },
                {
                  "kind": "account",
                  "path": "pool"
                }
              ]
            }
          }
        ],
        "args": [
          {
            "name": "amount",
            "type": "u64"
          }
        ]
      },
      {
        "name": "pausePool",
        "discriminator": [
          160,
          15,
          12,
          189,
          160,
          0,
          243,
          245
        ],
        "accounts": [
          {
            "name": "pool",
            "writable": true
          },
          {
            "name": "user",
            "writable": true,
            "signer": true
          },
          {
            "name": "participants",
            "pda": {
              "seeds": [
                {
                  "kind": "const",
                  "value": [
                    112,
                    97,
                    114,
                    116,
                    105,
                    99,
                    105,
                    112,
                    97,
                    110,
                    116,
                    115
                  ]
                },
                {
                  "kind": "account",
                  "path": "pool"
                }
              ]
            }
          }
        ],
        "args": []
      },
      {
        "name": "payoutWinner",
        "discriminator": [
          192,
          241,
          157,
          158,
          130,
          150,
          10,
          8
        ],
        "accounts": [
          {
            "name": "mint",
            "writable": true,
            "relations": [
              "pool"
            ]
          },
          {
            "name": "pool",
            "writable": true
          },
          {
            "name": "poolToken",
            "writable": true
          },
          {
            "name": "winnerToken",
            "writable": true
          },
          {
            "name": "devToken",
            "writable": true
          },
          {
            "name": "treasuryToken",
            "writable": true
          },
          {
            "name": "tokenProgram",
            "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
          },
          {
            "name": "systemProgram",
            "address": "11111111111111111111111111111111"
          },
          {
            "name": "associatedTokenProgram",
            "address": "ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL"
          },
          {
            "name": "winnerPubkey"
          },
          {
            "name": "user",
            "writable": true,
            "signer": true
          },
          {
            "name": "participants",
            "writable": true,
            "pda": {
              "seeds": [
                {
                  "kind": "const",
                  "value": [
                    112,
                    97,
                    114,
                    116,
                    105,
                    99,
                    105,
                    112,
                    97,
                    110,
                    116,
                    115
                  ]
                },
                {
                  "kind": "account",
                  "path": "pool"
                }
              ]
            }
          }
        ],
        "args": []
      },
      {
        "name": "requestRandomness",
        "discriminator": [
          213,
          5,
          173,
          166,
          37,
          236,
          31,
          18
        ],
        "accounts": [
          {
            "name": "randomness"
          },
          {
            "name": "pool",
            "writable": true
          },
          {
            "name": "user",
            "signer": true
          },
          {
            "name": "participants",
            "pda": {
              "seeds": [
                {
                  "kind": "const",
                  "value": [
                    112,
                    97,
                    114,
                    116,
                    105,
                    99,
                    105,
                    112,
                    97,
                    110,
                    116,
                    115
                  ]
                },
                {
                  "kind": "account",
                  "path": "pool"
                }
              ]
            }
          }
        ],
        "args": []
      },
      {
        "name": "selectWinner",
        "discriminator": [
          119,
          66,
          44,
          236,
          79,
          158,
          82,
          51
        ],
        "accounts": [
          {
            "name": "pool",
            "writable": true
          },
          {
            "name": "randomness"
          },
          {
            "name": "user",
            "signer": true
          },
          {
            "name": "participants",
            "pda": {
              "seeds": [
                {
                  "kind": "const",
                  "value": [
                    112,
                    97,
                    114,
                    116,
                    105,
                    99,
                    105,
                    112,
                    97,
                    110,
                    116,
                    115
                  ]
                },
                {
                  "kind": "account",
                  "path": "pool"
                }
              ]
            }
          }
        ],
        "args": []
      },
      {
        "name": "setLockDuration",
        "discriminator": [
          197,
          198,
          131,
          75,
          25,
          116,
          20,
          111
        ],
        "accounts": [
          {
            "name": "pool",
            "writable": true
          },
          {
            "name": "user",
            "writable": true,
            "signer": true
          },
          {
            "name": "participants",
            "pda": {
              "seeds": [
                {
                  "kind": "const",
                  "value": [
                    112,
                    97,
                    114,
                    116,
                    105,
                    99,
                    105,
                    112,
                    97,
                    110,
                    116,
                    115
                  ]
                },
                {
                  "kind": "account",
                  "path": "pool"
                }
              ]
            }
          }
        ],
        "args": [
          {
            "name": "newLockDuration",
            "type": "i64"
          }
        ]
      },
      {
        "name": "sweepExpiredPool",
        "discriminator": [
          182,
          4,
          161,
          221,
          98,
          188,
          73,
          145
        ],
        "accounts": [
          {
            "name": "mint",
            "writable": true,
            "relations": [
              "pool"
            ]
          },
          {
            "name": "pool",
            "writable": true
          },
          {
            "name": "poolToken",
            "writable": true
          },
          {
            "name": "user",
            "writable": true,
            "signer": true
          },
          {
            "name": "tokenProgram",
            "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
          },
          {
            "name": "systemProgram",
            "address": "11111111111111111111111111111111"
          },
          {
            "name": "participants",
            "pda": {
              "seeds": [
                {
                  "kind": "const",
                  "value": [
                    112,
                    97,
                    114,
                    116,
                    105,
                    99,
                    105,
                    112,
                    97,
                    110,
                    116,
                    115
                  ]
                },
                {
                  "kind": "account",
                  "path": "pool"
                }
              ]
            }
          }
        ],
        "args": []
      },
      {
        "name": "unlockPool",
        "discriminator": [
          51,
          19,
          234,
          156,
          255,
          183,
          89,
          254
        ],
        "accounts": [
          {
            "name": "pool",
            "writable": true
          },
          {
            "name": "user",
            "writable": true,
            "signer": true
          },
          {
            "name": "participants",
            "pda": {
              "seeds": [
                {
                  "kind": "const",
                  "value": [
                    112,
                    97,
                    114,
                    116,
                    105,
                    99,
                    105,
                    112,
                    97,
                    110,
                    116,
                    115
                  ]
                },
                {
                  "kind": "account",
                  "path": "pool"
                }
              ]
            }
          }
        ],
        "args": []
      },
      {
        "name": "unpausePool",
        "discriminator": [
          241,
          148,
          129,
          243,
          222,
          125,
          125,
          160
        ],
        "accounts": [
          {
            "name": "pool",
            "writable": true
          },
          {
            "name": "user",
            "writable": true,
            "signer": true
          },
          {
            "name": "participants",
            "pda": {
              "seeds": [
                {
                  "kind": "const",
                  "value": [
                    112,
                    97,
                    114,
                    116,
                    105,
                    99,
                    105,
                    112,
                    97,
                    110,
                    116,
                    115
                  ]
                },
                {
                  "kind": "account",
                  "path": "pool"
                }
              ]
            }
          }
        ],
        "args": []
      }
    ],
    "accounts": [
      {
        "name": "participants",
        "discriminator": [
          174,
          28,
          107,
          228,
          164,
          250,
          83,
          170
        ]
      },
      {
        "name": "pool",
        "discriminator": [
          241,
          154,
          109,
          4,
          17,
          177,
          109,
          188
        ]
      }
    ],
    "events": [
      {
        "name": "forfeitedToTreasury",
        "discriminator": [
          39,
          110,
          130,
          240,
          19,
          62,
          31,
          116
        ]
      },
      {
        "name": "poolActivityEvent",
        "discriminator": [
          116,
          221,
          203,
          110,
          114,
          139,
          97,
          124
        ]
      },
      {
        "name": "poolStateEvent",
        "discriminator": [
          72,
          169,
          77,
          67,
          172,
          217,
          3,
          115
        ]
      },
      {
        "name": "refundBurned",
        "discriminator": [
          54,
          180,
          75,
          149,
          111,
          26,
          28,
          217
        ]
      },
      {
        "name": "refundClaimedEvent",
        "discriminator": [
          77,
          83,
          172,
          123,
          235,
          58,
          154,
          233
        ]
      },
      {
        "name": "rentClaimed",
        "discriminator": [
          33,
          17,
          4,
          121,
          228,
          7,
          100,
          136
        ]
      },
      {
        "name": "uiHint",
        "discriminator": [
          229,
          2,
          70,
          121,
          217,
          26,
          231,
          151
        ]
      },
      {
        "name": "winnerSelectedEvent",
        "discriminator": [
          88,
          68,
          76,
          70,
          235,
          254,
          7,
          92
        ]
      }
    ],
    "errors": [
      {
        "code": 6000,
        "name": "poolExpired",
        "msg": "Pool has expired"
      },
      {
        "code": 6001,
        "name": "poolNotExpired",
        "msg": "Pool not expired"
      },
      {
        "code": 6002,
        "name": "poolNotEmpty",
        "msg": "Pool not empty"
      },
      {
        "code": 6003,
        "name": "notCreator",
        "msg": "Not creator"
      },
      {
        "code": 6004,
        "name": "notDeveloper",
        "msg": "Not developer"
      },
      {
        "code": 6005,
        "name": "unauthorized",
        "msg": "unauthorized"
      },
      {
        "code": 6006,
        "name": "alreadyParticipated",
        "msg": "Already participated"
      },
      {
        "code": 6007,
        "name": "maxParticipantsReached",
        "msg": "Maximum participants reached"
      },
      {
        "code": 6008,
        "name": "poolClosed",
        "msg": "Pool is closed"
      },
      {
        "code": 6009,
        "name": "overflow",
        "msg": "overflow"
      },
      {
        "code": 6010,
        "name": "invalidWinnerAccount",
        "msg": "Invalid winner account"
      },
      {
        "code": 6011,
        "name": "invalidParticipantToken",
        "msg": "Invalid participant token"
      },
      {
        "code": 6012,
        "name": "invalidMint",
        "msg": "Invalid mint"
      },
      {
        "code": 6013,
        "name": "mintHasMintAuthority",
        "msg": "Mint has mint authority"
      },
      {
        "code": 6014,
        "name": "mintHasFreezeAuthority",
        "msg": "Mint has freeze authority"
      },
      {
        "code": 6015,
        "name": "invalidDecimals",
        "msg": "Invalid decimals"
      },
      {
        "code": 6016,
        "name": "excessiveFees",
        "msg": "Excessive fees"
      },
      {
        "code": 6017,
        "name": "invalidParticipantCount",
        "msg": "Invalid participant count"
      },
      {
        "code": 6018,
        "name": "invalidRandomnessAccount",
        "msg": "Invalid randomness account"
      },
      {
        "code": 6019,
        "name": "randomnessNotResolved",
        "msg": "Randomness not resolved"
      },
      {
        "code": 6020,
        "name": "noParticipants",
        "msg": "No participants"
      },
      {
        "code": 6021,
        "name": "invalidPoolStatus",
        "msg": "Invalid pool status"
      },
      {
        "code": 6022,
        "name": "randomnessAlreadySet",
        "msg": "Randomness already set"
      },
      {
        "code": 6023,
        "name": "cannotDecreaseLockDuration",
        "msg": "Cannot decrease lock duration"
      },
      {
        "code": 6024,
        "name": "randomnessNotCommitted",
        "msg": "Randomness not committed"
      },
      {
        "code": 6025,
        "name": "randomnessNotRevealed",
        "msg": "Randomness not revealed"
      },
      {
        "code": 6026,
        "name": "invalidRandomness",
        "msg": "Invalid randomness"
      },
      {
        "code": 6027,
        "name": "tooManyParticipants",
        "msg": "Too many participants"
      },
      {
        "code": 6028,
        "name": "invalidParticipantRange",
        "msg": "Invalid participant range"
      },
      {
        "code": 6029,
        "name": "invalidAmount",
        "msg": "Invalid amount"
      },
      {
        "code": 6030,
        "name": "invalidLockDuration",
        "msg": "Invalid lock duration"
      },
      {
        "code": 6031,
        "name": "poolStillLocked",
        "msg": "Pool is still locked"
      },
      {
        "code": 6032,
        "name": "invalidParticipantsPda",
        "msg": "Invalid participants PDA"
      },
      {
        "code": 6033,
        "name": "insufficientFundsForBurn",
        "msg": "Insufficient funds for burn"
      },
      {
        "code": 6034,
        "name": "invalidTokenProgram",
        "msg": "Invalid token program"
      },
      {
        "code": 6035,
        "name": "zeroSupply",
        "msg": "Zero supply"
      },
      {
        "code": 6036,
        "name": "spoofedDonation",
        "msg": "Spoofed donation"
      },
      {
        "code": 6037,
        "name": "invalidWinnerPubkey",
        "msg": "Invalid winner pubkey"
      },
      {
        "code": 6038,
        "name": "invalidWinnerTokenOwner",
        "msg": "Invalid winner token owner"
      },
      {
        "code": 6039,
        "name": "forbiddenExtension",
        "msg": "Mint has unsupported extensions"
      },
      {
        "code": 6040,
        "name": "hasDelegate",
        "msg": "ATA has delegate"
      },
      {
        "code": 6041,
        "name": "hasCloseAuthority",
        "msg": "ATA has close authority"
      },
      {
        "code": 6042,
        "name": "paused",
        "msg": "Pool is paused"
      },
      {
        "code": 6043,
        "name": "configMismatch",
        "msg": "Config mismatch"
      },
      {
        "code": 6044,
        "name": "frozenAccount",
        "msg": "Account is frozen"
      },
      {
        "code": 6045,
        "name": "insufficientFunds",
        "msg": "Insufficient funds"
      },
      {
        "code": 6046,
        "name": "uninitializedAccount",
        "msg": "Uninitialized account"
      },
      {
        "code": 6047,
        "name": "randomnessExpired",
        "msg": "Randomness expired"
      },
      {
        "code": 6048,
        "name": "alreadyInitialized",
        "msg": "Account already initialized"
      },
      {
        "code": 6049,
        "name": "poolUnavailableForJoin",
        "msg": "Pool unavailable for join"
      },
      {
        "code": 6050,
        "name": "poolLockedForJoin",
        "msg": "Cannot join because lock has started"
      },
      {
        "code": 6051,
        "name": "dustNotAllowed",
        "msg": "Dust not allowed"
      },
      {
        "code": 6052,
        "name": "joinClosedAfterUnlock",
        "msg": "Pool has already unlocked - joining closed"
      },
      {
        "code": 6053,
        "name": "donateClosedAfterUnlock",
        "msg": "Donations are closed after unlocking"
      },
      {
        "code": 6054,
        "name": "tooEarlyForEmergency",
        "msg": "Too early for emergency finalize"
      },
      {
        "code": 6055,
        "name": "notParticipant",
        "msg": "Not participant"
      },
      {
        "code": 6056,
        "name": "alreadyEnded",
        "msg": "Pool already ended"
      },
      {
        "code": 6057,
        "name": "cannotChangeAfterJoins",
        "msg": "Cannot change lock duration after participants joined"
      },
      {
        "code": 6058,
        "name": "noWinnerSelected",
        "msg": "No winner selected"
      }
    ],
    "types": [
      {
        "name": "actionType",
        "repr": {
          "kind": "rust"
        },
        "type": {
          "kind": "enum",
          "variants": [
            {
              "name": "created"
            },
            {
              "name": "joined"
            },
            {
              "name": "donated"
            },
            {
              "name": "closed"
            },
            {
              "name": "ended"
            },
            {
              "name": "cancelled"
            },
            {
              "name": "randomnessCommitted"
            },
            {
              "name": "randomnessMockCommitted"
            },
            {
              "name": "reachedMax"
            },
            {
              "name": "unlocked"
            },
            {
              "name": "adminClosed"
            },
            {
              "name": "emergencyReveal"
            },
            {
              "name": "expired"
            }
          ]
        }
      },
      {
        "name": "forfeitedToTreasury",
        "type": {
          "kind": "struct",
          "fields": [
            {
              "name": "poolId",
              "type": "pubkey"
            },
            {
              "name": "amount",
              "type": "u64"
            }
          ]
        }
      },
      {
        "name": "hintType",
        "repr": {
          "kind": "rust"
        },
        "type": {
          "kind": "enum",
          "variants": [
            {
              "name": "reachedMax"
            },
            {
              "name": "nearExpire"
            },
            {
              "name": "unlocked"
            }
          ]
        }
      },
      {
        "name": "participants",
        "type": {
          "kind": "struct",
          "fields": [
            {
              "name": "list",
              "type": {
                "array": [
                  "pubkey",
                  20
                ]
              }
            },
            {
              "name": "count",
              "type": "u8"
            }
          ]
        }
      },
      {
        "name": "pool",
        "type": {
          "kind": "struct",
          "fields": [
            {
              "name": "poolId",
              "type": "u64"
            },
            {
              "name": "salt",
              "type": {
                "array": [
                  "u8",
                  32
                ]
              }
            },
            {
              "name": "mint",
              "type": "pubkey"
            },
            {
              "name": "creator",
              "type": "pubkey"
            },
            {
              "name": "startTime",
              "type": "i64"
            },
            {
              "name": "duration",
              "type": "i64"
            },
            {
              "name": "expireTime",
              "type": "i64"
            },
            {
              "name": "endTime",
              "type": "i64"
            },
            {
              "name": "unlockTime",
              "type": "i64"
            },
            {
              "name": "closeTime",
              "type": "i64"
            },
            {
              "name": "maxParticipants",
              "type": "u8"
            },
            {
              "name": "lockDuration",
              "type": "i64"
            },
            {
              "name": "lockStartTime",
              "type": "i64"
            },
            {
              "name": "amount",
              "type": "u64"
            },
            {
              "name": "totalAmount",
              "type": "u64"
            },
            {
              "name": "totalVolume",
              "type": "u64"
            },
            {
              "name": "totalJoins",
              "type": "u32"
            },
            {
              "name": "totalDonations",
              "type": "u32"
            },
            {
              "name": "devWallet",
              "type": "pubkey"
            },
            {
              "name": "devFeeBps",
              "type": "u16"
            },
            {
              "name": "burnFeeBps",
              "type": "u16"
            },
            {
              "name": "treasuryWallet",
              "type": "pubkey"
            },
            {
              "name": "treasuryFeeBps",
              "type": "u16"
            },
            {
              "name": "randomness",
              "type": "u128"
            },
            {
              "name": "randomnessAccount",
              "type": "pubkey"
            },
            {
              "name": "randomnessDeadlineSlot",
              "type": "u64"
            },
            {
              "name": "bump",
              "type": "u8"
            },
            {
              "name": "status",
              "type": {
                "defined": {
                  "name": "poolStatus"
                }
              }
            },
            {
              "name": "paused",
              "type": "bool"
            },
            {
              "name": "version",
              "type": "u8"
            },
            {
              "name": "schema",
              "type": "u8"
            },
            {
              "name": "configHash",
              "type": {
                "array": [
                  "u8",
                  32
                ]
              }
            },
            {
              "name": "allowMock",
              "type": "bool"
            },
            {
              "name": "randomnessCommitSlot",
              "type": "u64"
            },
            {
              "name": "initialized",
              "type": "bool"
            },
            {
              "name": "lastJoinTime",
              "type": "i64"
            },
            {
              "name": "statusReason",
              "type": "u8"
            },
            {
              "name": "participantsAccount",
              "type": "pubkey"
            },
            {
              "name": "winner",
              "type": "pubkey"
            }
          ]
        }
      },
      {
        "name": "poolActivityEvent",
        "type": {
          "kind": "struct",
          "fields": [
            {
              "name": "poolId",
              "type": "pubkey"
            },
            {
              "name": "numericalPoolId",
              "type": "u64"
            },
            {
              "name": "action",
              "type": {
                "defined": {
                  "name": "actionType"
                }
              }
            },
            {
              "name": "amount",
              "type": "u64"
            },
            {
              "name": "participantRank",
              "type": "u8"
            },
            {
              "name": "devFeePercent",
              "type": "u16"
            },
            {
              "name": "burnFeePercent",
              "type": "u16"
            },
            {
              "name": "treasuryFeePercent",
              "type": "u16"
            }
          ]
        }
      },
      {
        "name": "poolStateEvent",
        "type": {
          "kind": "struct",
          "fields": [
            {
              "name": "poolId",
              "type": "pubkey"
            },
            {
              "name": "numericalPoolId",
              "type": "u64"
            },
            {
              "name": "status",
              "type": {
                "defined": {
                  "name": "poolStatus"
                }
              }
            },
            {
              "name": "participantCount",
              "type": "u8"
            },
            {
              "name": "totalAmount",
              "type": "u64"
            },
            {
              "name": "statusReason",
              "type": "u8"
            }
          ]
        }
      },
      {
        "name": "poolStatus",
        "repr": {
          "kind": "rust"
        },
        "type": {
          "kind": "enum",
          "variants": [
            {
              "name": "open"
            },
            {
              "name": "locked"
            },
            {
              "name": "unlocked"
            },
            {
              "name": "randomnessCommitted"
            },
            {
              "name": "randomnessRevealed"
            },
            {
              "name": "winnerSelected"
            },
            {
              "name": "ended"
            },
            {
              "name": "cancelled"
            },
            {
              "name": "closed"
            }
          ]
        }
      },
      {
        "name": "refundBurned",
        "type": {
          "kind": "struct",
          "fields": [
            {
              "name": "user",
              "type": "pubkey"
            },
            {
              "name": "amount",
              "type": "u64"
            },
            {
              "name": "reason",
              "type": "u8"
            }
          ]
        }
      },
      {
        "name": "refundClaimedEvent",
        "type": {
          "kind": "struct",
          "fields": [
            {
              "name": "poolId",
              "type": "pubkey"
            },
            {
              "name": "user",
              "type": "pubkey"
            },
            {
              "name": "amount",
              "type": "u64"
            },
            {
              "name": "burnAmount",
              "type": "u64"
            },
            {
              "name": "reason",
              "type": "u8"
            }
          ]
        }
      },
      {
        "name": "rentClaimed",
        "type": {
          "kind": "struct",
          "fields": [
            {
              "name": "poolId",
              "type": "pubkey"
            },
            {
              "name": "caller",
              "type": "pubkey"
            },
            {
              "name": "sentTo",
              "type": "pubkey"
            },
            {
              "name": "timestamp",
              "type": "i64"
            }
          ]
        }
      },
      {
        "name": "uiHint",
        "type": {
          "kind": "struct",
          "fields": [
            {
              "name": "poolId",
              "type": "pubkey"
            },
            {
              "name": "hint",
              "type": {
                "defined": {
                  "name": "hintType"
                }
              }
            }
          ]
        }
      },
      {
        "name": "winnerSelectedEvent",
        "type": {
          "kind": "struct",
          "fields": [
            {
              "name": "poolId",
              "type": "pubkey"
            },
            {
              "name": "numericalPoolId",
              "type": "u64"
            },
            {
              "name": "winner",
              "type": "pubkey"
            },
            {
              "name": "winnerAmount",
              "type": "u64"
            },
            {
              "name": "devAmount",
              "type": "u64"
            },
            {
              "name": "burnAmount",
              "type": "u64"
            },
            {
              "name": "treasuryAmount",
              "type": "u64"
            },
            {
              "name": "randomness",
              "type": "u128"
            }
          ]
        }
      }
    ]
  } as const;
  
// -------------------- Extra local app types --------------------

export interface WalletInfo {
  id: bigint;
  pubkey: string; // ✅ same as Prisma model
  isDefault: boolean;
}

export interface User {
  id: bigint;
  tgId: bigint;
  username?: string;
  wallets: WalletInfo[];
}

export interface PoolState {
  poolId: string;
  currentParticipants: number;
  maxParticipants: number;
  status: string;
  mint: string;
  totalAmount: string;
  amountPerJoin: string;
  creator: string;
  salt: string;
  participantsPda: string;
  lockStartTime: number;
  lockDuration: number;
  lockEndTime: Date;
  startTime: Date;
}

export interface PoolCreationResult {
  poolId: string;
  txHash: string;
}