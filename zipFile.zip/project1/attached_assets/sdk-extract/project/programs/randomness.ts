import * as anchor from "@coral-xyz/anchor";
import { TransactionInstruction } from "@solana/web3.js";

/**
 * Thin wrapper around your Anchor randomness methods.
 *
 * IMPORTANT:
 *  - ONLY builds instructions (no tx sending)
 *  - randomness-service is responsible for signing/sending
 *  - clean separation of responsibilities
 */
export class RandomnessProgram {
  constructor(public program: anchor.Program<any>) {}

  /**
   * ----------------------------------------------------
   * UNLOCK POOL  (dev wallet only)
   * ----------------------------------------------------
   */
  async unlockPool(accounts: Record<string, any>): Promise<TransactionInstruction> {
    try {
      return await this.program.methods
        .unlockPool()
        .accounts(accounts)
        .instruction();
    } catch (err: any) {
      console.error("unlockPool build failed:", err.message);
      throw err;
    }
  }

  /**
   * ----------------------------------------------------
   * REQUEST RANDOMNESS  (after unlock)
   * ----------------------------------------------------
   */
  async requestRandomness(accounts: Record<string, any>): Promise<TransactionInstruction> {
    try {
      return await this.program.methods
        .requestRandomness()
        .accounts(accounts)
        .instruction();
    } catch (err: any) {
      console.error("requestRandomness build failed:", err.message);
      throw err;
    }
  }

  /**
   * ----------------------------------------------------
   * SELECT WINNER  (after randomness revealed)
   * MUST be called BEFORE payoutWinner
   * ----------------------------------------------------
   */
  async selectWinner(accounts: Record<string, any>): Promise<TransactionInstruction> {
    try {
      return await this.program.methods
        .selectWinner()
        .accounts(accounts)
        .instruction();
    } catch (err: any) {
      console.error("selectWinner build failed:", err.message);
      throw err;
    }
  }

  /**
   * ----------------------------------------------------
   * PAYOUT WINNER
   * Requires:
   *  - pool.status == WinnerSelected
   *  - valid randomness
   * ----------------------------------------------------
   */
  async payoutWinner(accounts: Record<string, any>): Promise<TransactionInstruction> {
    try {
      return await this.program.methods
        .payoutWinner()
        .accounts(accounts)
        .instruction();
    } catch (err: any) {
      console.error("payoutWinner build failed:", err.message);
      throw err;
    }
  }
}
