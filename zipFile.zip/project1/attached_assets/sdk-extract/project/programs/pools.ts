import * as anchor from "@coral-xyz/anchor";
import { TransactionInstruction, PublicKey } from "@solana/web3.js";

/**
 * PoolsProgram
 * - All `.methods.*` calls are cast to `any` to avoid TS recursion bugs.
 * - Runtime stays identical to real Anchor behavior.
 */
export class PoolsProgram {
  constructor(private program: anchor.Program<any>) {}

  /* -------------------------------------------------------
   * INTERNAL SAFE GETTER — FIXES TS INFINITE TYPE BUG
   * ------------------------------------------------------- */
  private m(): any {
    return this.program.methods as any;
  }

  /* -------------------------------------------------------
   * CREATE POOL
   * ------------------------------------------------------- */
  async createPool(
    params: {
      salt: number[];
      maxParticipants: number;
      lockDuration: number;
      amount: anchor.BN;
      devWallet: PublicKey;
      devFeeBps: number;
      burnFeeBps: number;
      treasuryWallet: PublicKey;
      treasuryFeeBps: number;
      allowMock: boolean;
    },
    accounts: Record<string, any>
  ): Promise<TransactionInstruction> {
    const m = this.m();

    return m
      .createPool(
        params.salt,
        params.maxParticipants,
        params.lockDuration,
        params.amount,
        params.devWallet,
        params.devFeeBps,
        params.burnFeeBps,
        params.treasuryWallet,
        params.treasuryFeeBps,
        params.allowMock
      )
      .accounts(accounts)
      .instruction();
  }

  /* -------------------------------------------------------
   * JOIN POOL
   * ------------------------------------------------------- */
  async joinPool(amountBn: anchor.BN, accounts: any) {
    const m = this.m();
    return m.joinPool(amountBn).accounts(accounts).instruction();
  }

  /* -------------------------------------------------------
   * DONATE
   * ------------------------------------------------------- */
  async donate(amountBn: anchor.BN, accounts: any) {
    const m = this.m();
    return m.donate(amountBn).accounts(accounts).instruction();
  }

  /* -------------------------------------------------------
   * SET LOCK DURATION
   * ------------------------------------------------------- */
  async setLockDuration(newLockDuration: anchor.BN, accounts: any) {
    const m = this.m();
    return m.setLockDuration(newLockDuration).accounts(accounts).instruction();
  }

  /* -------------------------------------------------------
   * CANCEL POOL
   * ------------------------------------------------------- */
  async cancelPool(accounts: any) {
    const m = this.m();
    return m.cancelPool().accounts(accounts).instruction();
  }

  /* -------------------------------------------------------
   * ADMIN CLOSE POOL
   * ------------------------------------------------------- */
  async adminClosePool(accounts: any) {
    const m = this.m();
    return m.adminClosePool().accounts(accounts).instruction();
  }

  /* -------------------------------------------------------
   * SWEEP EXPIRED
   * ------------------------------------------------------- */
  async sweepExpiredPool(accounts: any) {
    const m = this.m();
    return m.sweepExpiredPool().accounts(accounts).instruction();
  }

  /* -------------------------------------------------------
   * CLAIM REFUND
   * ------------------------------------------------------- */
  async claimRefund(accounts: any) {
    const m = this.m();
    return m.claimRefund().accounts(accounts).instruction();
  }

  /* -------------------------------------------------------
   * CLOSE POOL
   * ------------------------------------------------------- */
  async closePool(accounts: any) {
    const m = this.m();
    return m.closePool().accounts(accounts).instruction();
  }

  /* -------------------------------------------------------
   * CLAIM RENT
   * ------------------------------------------------------- */
  async claimRent(accounts: any) {
    const m = this.m();
    return m.claimRent().accounts(accounts).instruction();
  }

  /* -------------------------------------------------------
   * PAUSE POOL
   * ------------------------------------------------------- */
  async pausePool(accounts: any) {
    const m = this.m();
    return m.pausePool().accounts(accounts).instruction();
  }

  /* -------------------------------------------------------
   * UNPAUSE POOL
   * ------------------------------------------------------- */
  async unpausePool(accounts: any) {
    const m = this.m();
    return m.unpausePool().accounts(accounts).instruction();
  }

  /* -------------------------------------------------------
   * FORCE EXPIRE (mock)
   * ------------------------------------------------------- */
  async forceExpire(accounts: any) {
    const m = this.m();
    return m.forceExpire().accounts(accounts).instruction();
  }

  /* -------------------------------------------------------
   * FINALIZE FORFEITED
   * ------------------------------------------------------- */
  async finalizeForfeitedPool(accounts: any) {
    const m = this.m();
    return m.finalizeForfeitedPool().accounts(accounts).instruction();
  }
}
