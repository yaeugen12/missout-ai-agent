import * as anchor from "@coral-xyz/anchor";

export class RewardsProgram {
  constructor(private program: anchor.Program<any>) {}

  async claimReferralRewards(accounts: any) {
    const methods: any = this.program.methods;

    return methods
      .claimReferralRewards()
      .accounts(accounts)
      .instruction();
  }
}
