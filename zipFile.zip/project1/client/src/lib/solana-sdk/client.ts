import * as anchor from "@coral-xyz/anchor";
import { Program, AnchorProvider } from "@coral-xyz/anchor";
import { PublicKey, Connection, VersionedTransaction, TransactionMessage, ComputeBudgetProgram } from "@solana/web3.js";
import { WalletContextState } from "@solana/wallet-adapter-react";

import { getConnection, initConnection, getConnectionInfo } from "./connection";
import { PROGRAM_ID } from "./programs/program-id";
import { deriveParticipantsPda } from "./pda/derive";
import { IDL } from "./idl";

export interface PoolState {
  version: number;
  bump: number;
  poolId: anchor.BN;
  salt: Uint8Array; // [u8; 32]
  creator: PublicKey;
  mint: PublicKey;
  amount: anchor.BN;
  maxParticipants: number;
  startTime: anchor.BN; // i64
  duration: anchor.BN; // i64
  expireTime: anchor.BN; // i64
  lockDuration: anchor.BN;
  lockStartTime: anchor.BN;
  endTime: anchor.BN; // i64
  unlockTime: anchor.BN; // i64
  devWallet: PublicKey;
  devFeeBps: number;
  burnFeeBps: number;
  treasuryWallet: PublicKey;
  treasuryFeeBps: number;
  participantsAccount: PublicKey;
  status: any;
  winner: PublicKey;
  randomnessAccount: PublicKey;
  allowMock: boolean;
  closeTime: anchor.BN;
  totalAmount: anchor.BN; // u64
  totalVolume: anchor.BN; // u64
  totalJoins: number; // u32
  totalDonations: number; // u32
  randomness: anchor.BN; // u128
  randomnessDeadlineSlot: anchor.BN; // u64
  paused: boolean;
  schema: number; // u8
  configHash: Uint8Array; // [u8; 32]
  randomnessCommitSlot: anchor.BN; // u64
  initialized: boolean;
  lastJoinTime: anchor.BN; // i64
  statusReason: number; // u8
}

export interface ParticipantsState {
  count: number;
  list: PublicKey[]; // Filtered from fixed array [Pubkey; 20], removing default pubkeys
}

export class MissoutClient {
  private connection: Connection;
  private wallet: WalletContextState | null = null;
  private program: any = null;

  constructor() {
    this.connection = getConnection();
    // Start async initialization
    initConnection().catch(console.error);
  }

  setWallet(wallet: WalletContextState) {
    this.wallet = wallet;

    // Initialize Anchor Program when wallet is connected
    if (wallet.publicKey && wallet.signTransaction) {
      try {
        const provider = new AnchorProvider(
          this.connection,
          wallet as any,
          { commitment: "confirmed" }
        );
        this.program = new Program(IDL as any, provider);
        console.log("[MissoutClient] Anchor Program initialized");
      } catch (err) {
        console.error("[MissoutClient] Failed to initialize Anchor Program:", err);
      }
    }
  }

  getConnection() {
    return this.connection;
  }

  getConnectionInfo() {
    return getConnectionInfo();
  }

  getWallet() {
    return this.wallet;
  }

  isReady(): boolean {
    return this.wallet !== null && this.wallet.connected && this.wallet.publicKey !== null;
  }

  async getPoolState(poolId: string): Promise<PoolState | null> {
    try {
      const pubkey = new PublicKey(poolId);

      // Use Anchor Program if available
      if (this.program) {
        try {
          // Note: IDL defines account as "Pool" (capitalized)
          const poolData = await (this.program.account as any).Pool.fetch(pubkey);
          return poolData as PoolState;
        } catch (anchorErr) {
          console.error("[MissoutClient] Anchor fetch failed, falling back to manual parsing:", anchorErr);
        }
      }

      // Fallback: manual parsing for read-only without wallet
      const acc = await this.connection.getAccountInfo(pubkey);
      if (!acc) return null;
      if (!acc.owner.equals(PROGRAM_ID)) {
        console.warn(`[MissoutClient] Account ${poolId} is not owned by program`);
        return null;
      }

      console.warn("[MissoutClient] Using legacy buffer parsing - Anchor Program not available");
      const dataView = new DataView(acc.data.buffer, acc.data.byteOffset, acc.data.byteLength);
      return this.decodePoolFromBuffer(dataView, acc.data);
    } catch (err) {
      console.error("getPoolState error:", err);
      return null;
    }
  }

  private decodePoolFromBuffer(dataView: DataView, data: Uint8Array): PoolState {
    // LEGACY: This method provides backward compatibility when Anchor Program is not available
    // NOTE: This parsing is based on the OLD Pool structure and may not work with the NEW IDL
    // It's recommended to always use Anchor Program deserialization by connecting a wallet

    const MIN_POOL_SIZE = 8 + 2 + 32 + 32 + 8 + 2 + 8 + 8 + 32 + 2 + 2 + 32 + 2 + 32 + 1 + 32 + 32 + 1 + 8;
    if (data.length < MIN_POOL_SIZE) {
      throw new Error(`Pool account too short: ${data.length} < ${MIN_POOL_SIZE}`);
    }

    let offset = 8;

    const version = data[offset++];
    const bump = data[offset++];
    const creator = new PublicKey(data.slice(offset, offset + 32)); offset += 32;
    const mint = new PublicKey(data.slice(offset, offset + 32)); offset += 32;
    const amount = new anchor.BN(data.slice(offset, offset + 8), 'le'); offset += 8;
    const maxParticipants = dataView.getUint16(offset, true); offset += 2;
    const lockDuration = new anchor.BN(data.slice(offset, offset + 8), 'le'); offset += 8;
    const lockStartTime = new anchor.BN(data.slice(offset, offset + 8), 'le'); offset += 8;
    const devWallet = new PublicKey(data.slice(offset, offset + 32)); offset += 32;
    const devFeeBps = dataView.getUint16(offset, true); offset += 2;
    const burnFeeBps = dataView.getUint16(offset, true); offset += 2;
    const treasuryWallet = new PublicKey(data.slice(offset, offset + 32)); offset += 32;
    const treasuryFeeBps = dataView.getUint16(offset, true); offset += 2;
    const participantsAccount = new PublicKey(data.slice(offset, offset + 32)); offset += 32;
    const statusByte = data[offset++];
    const status = this.decodeStatus(statusByte);
    const winner = new PublicKey(data.slice(offset, offset + 32)); offset += 32;
    const randomnessAccount = new PublicKey(data.slice(offset, offset + 32)); offset += 32;
    const allowMock = data[offset++] === 1;
    const closeTime = new anchor.BN(data.slice(offset, offset + 8), 'le');

    // Fill in missing fields with default values (for backward compatibility)
    const defaultPubkey = PublicKey.default;
    const defaultBN = new anchor.BN(0);
    const defaultBytes32 = new Uint8Array(32);

    return {
      version, bump, creator, mint, amount, maxParticipants, lockDuration,
      lockStartTime, devWallet, devFeeBps, burnFeeBps, treasuryWallet,
      treasuryFeeBps, participantsAccount, status, winner, randomnessAccount,
      allowMock, closeTime,
      // NEW fields with defaults
      poolId: defaultBN,
      salt: defaultBytes32,
      startTime: defaultBN,
      duration: defaultBN,
      expireTime: defaultBN,
      endTime: defaultBN,
      unlockTime: defaultBN,
      totalAmount: defaultBN,
      totalVolume: defaultBN,
      totalJoins: 0,
      totalDonations: 0,
      randomness: defaultBN,
      randomnessDeadlineSlot: defaultBN,
      paused: false,
      schema: 0,
      configHash: defaultBytes32,
      randomnessCommitSlot: defaultBN,
      initialized: true,
      lastJoinTime: defaultBN,
      statusReason: 0,
    };
  }

  private decodeStatus(statusByte: number): any {
    const statuses = ['open', 'locked', 'unlocked', 'randomnessRequested', 'winnerSelected', 'ended', 'cancelled', 'paused'];
    const name = statuses[statusByte] || 'unknown';
    return { [name]: {} };
  }

  async getParticipantsState(poolId: string): Promise<ParticipantsState | null> {
    try {
      const poolPk = new PublicKey(poolId);
      const [participantsPda] = deriveParticipantsPda(poolPk);

      // Use Anchor Program if available
      if (this.program) {
        try {
          const participantsData = await this.program.account.Participants.fetch(participantsPda);
          // Filter out default pubkeys from fixed array [Pubkey; 20]
          const defaultPubkey = PublicKey.default.toBase58();
          const filteredList = participantsData.list.filter(
            (pk: PublicKey) => pk.toBase58() !== defaultPubkey
          );
          return {
            count: participantsData.count,
            list: filteredList,
          };
        } catch (anchorErr) {
          console.error("[MissoutClient] Anchor fetch failed for Participants, falling back:", anchorErr);
        }
      }

      // Fallback: manual parsing
      const acc = await this.connection.getAccountInfo(participantsPda);
      if (!acc) return null;

      console.warn("[MissoutClient] Using legacy Participants parsing - Anchor Program not available");
      return this.decodeParticipantsFromBuffer(acc.data);
    } catch (err) {
      console.error("getParticipantsState error:", err);
      return null;
    }
  }

  private decodeParticipantsFromBuffer(data: Uint8Array): ParticipantsState {
    // LEGACY: This method provides backward compatibility when Anchor Program is not available
    // NOTE: This parsing is based on the OLD Participants structure (Vec<Pubkey>)
    // The NEW IDL uses a fixed array [Pubkey; 20] - use Anchor Program for accurate parsing

    const MIN_PARTICIPANTS_SIZE = 8 + 32 + 2 + 4;
    if (data.length < MIN_PARTICIPANTS_SIZE) {
      throw new Error(`Participants account too short: ${data.length} < ${MIN_PARTICIPANTS_SIZE}`);
    }

    let offset = 8;
    const dataView = new DataView(data.buffer, data.byteOffset, data.byteLength);

    // Skip pool field (not in new interface)
    offset += 32;
    const count = dataView.getUint16(offset, true); offset += 2;

    const list: PublicKey[] = [];
    const vecLen = dataView.getUint32(offset, true); offset += 4;

    const expectedLen = offset + vecLen * 32;
    if (data.length < expectedLen) {
      console.warn(`Participants list truncated: expected ${expectedLen} bytes, got ${data.length}`);
    }

    for (let i = 0; i < vecLen && offset + 32 <= data.length; i++) {
      list.push(new PublicKey(data.slice(offset, offset + 32)));
      offset += 32;
    }

    return { count, list };
  }

  getPoolStatus(status: any): string {
    if (!status) return "unknown";
    const key = Object.keys(status)[0];
    return key.toLowerCase();
  }

  /**
   * RPC Health Check - verifies connection before transaction
   */
  async checkRpcHealth(): Promise<{ ok: boolean; error?: string }> {
    try {
      console.log("SDK_RPC_HEALTHCHECK: Checking...", this.connection.rpcEndpoint);
      const version = await this.connection.getVersion();
      console.log("SDK_RPC_HEALTHCHECK_OK: Solana version", version["solana-core"]);
      return { ok: true };
    } catch (err: any) {
      console.error("SDK_RPC_HEALTHCHECK_FAIL:", err.message);
      return { ok: false, error: err.message };
    }
  }

  async buildAndSendTransaction(
    instructions: anchor.web3.TransactionInstruction[],
    priorityFee = 5000
  ): Promise<string> {
    console.log("==============================================");
    console.log("=== BUILD_AND_SEND_TX_ENTER ===");
    console.log("Timestamp:", new Date().toISOString());
    console.log("RPC_ENDPOINT:", this.connection.rpcEndpoint);
    
    // Step 1: Wallet validation
    console.log("WALLET_STATE:", {
      hasWallet: !!this.wallet,
      hasPublicKey: !!this.wallet?.publicKey,
      publicKey: this.wallet?.publicKey?.toBase58() || "null",
      hasSignTransaction: typeof this.wallet?.signTransaction === 'function',
      hasSendTransaction: typeof this.wallet?.sendTransaction === 'function',
      connected: this.wallet?.connected,
    });
    
    if (!this.wallet?.publicKey) {
      console.error("SDK_ABORT: Wallet not connected (no publicKey)");
      throw new Error("Wallet not connected");
    }
    
    // Check for either sendTransaction OR signTransaction
    const canSend = typeof this.wallet.sendTransaction === 'function';
    const canSign = typeof this.wallet.signTransaction === 'function';
    
    if (!canSend && !canSign) {
      console.error("SDK_ABORT: Wallet cannot sign or send transactions");
      throw new Error("Wallet cannot sign transactions");
    }

    console.log("WALLET_READY:", this.wallet.publicKey.toBase58());
    console.log("=== WALLET_METHOD_USED ===", canSend ? "sendTransaction" : "signTransaction");

    // Step 2: RPC Health Check
    const healthCheck = await this.checkRpcHealth();
    if (!healthCheck.ok) {
      console.error("SDK_RPC_FAIL:", healthCheck.error);
      throw new Error(`RPC connection failed: ${healthCheck.error}`);
    }

    // Ensure we are on devnet
    if (this.connection.rpcEndpoint.includes('mainnet')) {
      throw new Error("CRITICAL: Mainnet RPC detected during transaction build");
    }

    // Step 3: Get blockhash
    console.log("FETCHING_BLOCKHASH...");
    const { blockhash, lastValidBlockHeight } = await this.connection.getLatestBlockhash("finalized");
    console.log("BLOCKHASH:", blockhash, "HEIGHT:", lastValidBlockHeight);

    // Step 4: Build transaction
    const ixs = [
      ComputeBudgetProgram.setComputeUnitPrice({ microLamports: priorityFee }),
      ...instructions,
    ];

    console.log("BUILDING_TX_MESSAGE...");
    const message = new TransactionMessage({
      payerKey: this.wallet.publicKey,
      recentBlockhash: blockhash,
      instructions: ixs,
    }).compileToV0Message();

    const tx = new VersionedTransaction(message);
    console.log("SDK_BUILD_TX_OK:", tx.message.recentBlockhash);
    
    // Step 5: Simulate transaction
    console.log("SDK_SIMULATING...");
    try {
      const simulation = await this.connection.simulateTransaction(tx, { 
        commitment: 'finalized',
        replaceRecentBlockhash: true 
      });
      if (simulation.value.err) {
        console.error("SDK_SIMULATE_FAIL:", simulation.value.err);
        console.error("SDK_SIMULATE_LOGS:", simulation.value.logs);
        throw new Error(`Simulation failed: ${JSON.stringify(simulation.value.err)}`);
      }
      console.log("SDK_SIMULATE_OK: Units consumed:", simulation.value.unitsConsumed);
    } catch (simErr: any) {
      console.error("SDK_SIMULATE_ERROR:", simErr.message);
      // Continue anyway - let the user sign and see the real error
      console.warn("SDK_SIMULATE_WARN: Continuing despite simulation error...");
    }

    // Step 6: Send to wallet - THIS IS WHERE PHANTOM POPUP SHOULD APPEAR
    console.log("==============================================");
    console.log("==> SDK_SENDING_TO_WALLET <==");
    console.log("Phantom popup should appear NOW");
    console.log("==============================================");

    let sig: string;
    
    try {
      if (canSend) {
        console.log("=== CALLING_WALLET_SEND_TX ===");
        sig = await this.wallet.sendTransaction(tx, this.connection, {
          maxRetries: 5,
          skipPreflight: true,
        });
        console.log("=== WALLET_RETURNED_SIG ===", sig);
      } else {
        console.log("=== CALLING_WALLET_SIGN_TX ===");
        const signedTx = await this.wallet.signTransaction!(tx);
        console.log("=== WALLET_SIGNED_OK ===");
        
        console.log("=== SENDING_RAW_TX ===");
        sig = await this.connection.sendRawTransaction(signedTx.serialize(), {
          maxRetries: 5,
          skipPreflight: true,
        });
        console.log("=== RAW_TX_SENT ===", sig);
      }
    } catch (walletErr: any) {
      console.error("=== WALLET_ERROR ===", walletErr.message);
      if (walletErr.message?.includes('User rejected') || walletErr.message?.includes('rejected')) {
        throw new Error("Transaction cancelled by user");
      }
      throw walletErr;
    }
    
    console.log("SDK_TX_SENT:", sig);
    console.log(`Explorer: https://explorer.solana.com/tx/${sig}?cluster=devnet`);

    // Step 7: Confirm transaction
    console.log("SDK_CONFIRMING...");
    try {
      await this.connection.confirmTransaction(
        { signature: sig, blockhash, lastValidBlockHeight },
        "confirmed"
      );
      console.log("SDK_TX_CONFIRMED:", sig);
    } catch (confirmErr: any) {
      console.error("SDK_CONFIRM_ERROR:", confirmErr.message);
      // Transaction may still have succeeded - check status
      const status = await this.connection.getSignatureStatus(sig);
      if (status.value?.confirmationStatus) {
        console.log("SDK_TX_STATUS:", status.value.confirmationStatus);
      } else {
        throw confirmErr;
      }
    }
    
    console.log("=== BUILD_AND_SEND_TX_SUCCESS ===");
    console.log("==============================================");

    return sig;
  }
}

let clientInstance: MissoutClient | null = null;

export function getMissoutClient(): MissoutClient {
  if (!clientInstance) {
    clientInstance = new MissoutClient();
  }
  return clientInstance;
}
