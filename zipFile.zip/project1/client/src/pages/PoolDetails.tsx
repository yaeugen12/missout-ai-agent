// BUILD_ID: v8-join-donate-timer
const BUILD_ID = "v8-join-donate-timer";
console.log("=== POOL_DETAILS_LOADED ===", BUILD_ID);

import { useParams } from "wouter";
import { usePool } from "@/hooks/use-pools";
import { useWallet } from "@/hooks/use-wallet";
import { Navbar } from "@/components/Navbar";
import { BlackHoleCore } from "@/components/BlackHoleCore";
import { RouletteReveal } from "@/components/RouletteReveal";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Loader2, Trophy, Clock, Users, Coins, AlertTriangle, Ban, RefreshCw, Zap, Gift, XCircle, Heart } from "lucide-react";
import { useState, useEffect, useCallback } from "react";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { api } from "@shared/routes";
import { motion, AnimatePresence } from "framer-motion";
import clsx from "clsx";
import { useMissoutSDK } from "@/hooks/useMissoutSDK";
import { getSolscanTxUrl } from "@/hooks/use-sdk-transaction";
import { DevnetReadiness } from "@/components/DevnetReadiness";

export default function PoolDetails() {
  const { id } = useParams();
  const poolId = parseInt(id || "0");
  const { data: pool, isLoading, error } = usePool(poolId);
  const { isConnected, address, connect } = useWallet();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { joinPool, donateToPool, cancelPool, claimRefund, connected: sdkConnected } = useMissoutSDK();
  
  const [showRoulette, setShowRoulette] = useState(false);
  const [winnerRevealed, setWinnerRevealed] = useState(false);
  const [isJoining, setIsJoining] = useState(false);
  const [isCancelling, setIsCancelling] = useState(false);
  const [isClaimingRefund, setIsClaimingRefund] = useState(false);
  const [isDonating, setIsDonating] = useState(false);
  const [donateModalOpen, setDonateModalOpen] = useState(false);
  const [donateAmount, setDonateAmount] = useState("");
  const [countdown, setCountdown] = useState<number | null>(null);

  const poolAddress = pool?.poolAddress;
  const isCreator = pool?.creatorWallet === address;
  const hasJoined = pool?.participants.some(p => p.walletAddress === address);
  const canCancel = isCreator && pool?.status === 'open' && (pool?.participantsCount ?? 0) === 0;
  const canClaimRefund = hasJoined && pool?.status === 'cancelled';
  
  useEffect(() => {
    if (pool?.status === 'winnerSelected' && !winnerRevealed) {
      setShowRoulette(true);
    }
  }, [pool?.status, winnerRevealed]);

  // Countdown timer - only starts when pool is locked (lockStartTime is set)
  useEffect(() => {
    if (!pool?.lockStartTime || pool.status !== 'locked') {
      setCountdown(null);
      return;
    }

    const lockEndTime = pool.lockStartTime + (pool.lockDuration * 60); // lockDuration is in minutes
    
    const updateCountdown = () => {
      const now = Math.floor(Date.now() / 1000);
      const remaining = lockEndTime - now;
      setCountdown(remaining > 0 ? remaining : 0);
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);
    return () => clearInterval(interval);
  }, [pool?.lockStartTime, pool?.lockDuration, pool?.status]);

  const invalidateQueries = useCallback(() => {
    queryClient.invalidateQueries({ queryKey: [api.pools.list.path] });
    queryClient.invalidateQueries({ queryKey: [api.pools.get.path, poolId] });
  }, [queryClient, poolId]);

  const handleJoin = useCallback(async () => {
    console.log("=== JOIN_CLICK ===", BUILD_ID);
    
    if (!isConnected || !address) {
      console.log("JOIN: Wallet not connected, prompting connect");
      connect();
      return;
    }
    
    if (!poolAddress || !pool) {
      toast({ variant: "destructive", title: "Error", description: "Pool not ready" });
      return;
    }

    setIsJoining(true);
    try {
      console.log("=== SDK_JOIN_ENTER ===");
      console.log("JOIN params:", { poolId: poolAddress, amount: pool.entryAmount });
      
      const result = await joinPool({
        poolId: poolAddress,
        amount: pool.entryAmount.toString(),
      });
      
      console.log("=== JOIN_TX_CONFIRMED ===", result.tx);
      console.log("Join tx:", getSolscanTxUrl(result.tx));
      
      // POST to backend with txHash
      console.log("=== POSTING_JOIN_TO_BACKEND ===");
      await apiRequest("POST", `/api/pools/${poolId}/join`, {
        walletAddress: address,
        txHash: result.tx,
      });
      console.log("=== BACKEND_JOIN_SUCCESS ===");
      
      toast({
        title: "Pulled Into the Void",
        description: `You have successfully joined! Tx: ${result.tx.slice(0, 8)}...`,
      });
      
      invalidateQueries();
    } catch (err) {
      console.error("=== JOIN_ERROR ===", err);
      toast({
        variant: "destructive",
        title: "Pull Failed",
        description: err instanceof Error ? err.message : "Transaction failed",
      });
    } finally {
      setIsJoining(false);
    }
  }, [isConnected, address, poolAddress, pool, poolId, joinPool, toast, connect, invalidateQueries]);

  const handleDonate = useCallback(async () => {
    console.log("=== DONATE_CONFIRM_CLICK ===", BUILD_ID);
    
    if (!isConnected || !address) {
      connect();
      return;
    }
    
    if (!poolAddress || !pool) {
      toast({ variant: "destructive", title: "Error", description: "Pool not ready" });
      return;
    }

    const amount = parseFloat(donateAmount);
    if (isNaN(amount) || amount <= 0) {
      toast({ variant: "destructive", title: "Invalid Amount", description: "Please enter a valid amount" });
      return;
    }

    setIsDonating(true);
    try {
      console.log("=== SDK_DONATE_ENTER ===");
      console.log("DONATE params:", { poolId: poolAddress, amount });
      
      const result = await donateToPool({
        poolId: poolAddress,
        amount: amount.toString(),
      });
      
      console.log("=== DONATE_TX_CONFIRMED ===", result.tx);
      console.log("Donate tx:", getSolscanTxUrl(result.tx));
      
      // POST to backend with txHash
      console.log("=== POSTING_DONATE_TO_BACKEND ===");
      await apiRequest("POST", `/api/pools/${poolId}/donate`, {
        walletAddress: address,
        amount: amount,
        txHash: result.tx,
      });
      console.log("=== BACKEND_DONATE_SUCCESS ===");
      
      toast({
        title: "Fed the Void",
        description: `Donated ${amount} ${pool.tokenSymbol}! Tx: ${result.tx.slice(0, 8)}...`,
      });
      
      setDonateModalOpen(false);
      setDonateAmount("");
      invalidateQueries();
    } catch (err) {
      console.error("=== DONATE_ERROR ===", err);
      toast({
        variant: "destructive",
        title: "Donation Failed",
        description: err instanceof Error ? err.message : "Transaction failed",
      });
    } finally {
      setIsDonating(false);
    }
  }, [isConnected, address, poolAddress, pool, poolId, donateAmount, donateToPool, toast, connect, invalidateQueries]);

  const handleCancel = useCallback(async () => {
    if (!poolAddress) return;
    
    setIsCancelling(true);
    try {
      const result = await cancelPool(poolAddress);
      toast({
        title: "Pool Cancelled",
        description: `Black hole collapsed. Tx: ${result.tx.slice(0, 8)}...`,
      });
      console.log("Cancel tx:", getSolscanTxUrl(result.tx));
      invalidateQueries();
    } catch (err) {
      toast({
        variant: "destructive",
        title: "Cancel Failed",
        description: err instanceof Error ? err.message : "Transaction failed",
      });
    } finally {
      setIsCancelling(false);
    }
  }, [poolAddress, cancelPool, toast, invalidateQueries]);

  const handleClaimRefund = useCallback(async () => {
    if (!poolAddress) return;
    
    setIsClaimingRefund(true);
    try {
      const result = await claimRefund(poolAddress);
      toast({
        title: "Refund Claimed",
        description: `Tokens returned. Tx: ${result.tx.slice(0, 8)}...`,
      });
      console.log("Refund tx:", getSolscanTxUrl(result.tx));
      invalidateQueries();
    } catch (err) {
      toast({
        variant: "destructive",
        title: "Refund Failed",
        description: err instanceof Error ? err.message : "Transaction failed",
      });
    } finally {
      setIsClaimingRefund(false);
    }
  }, [poolAddress, claimRefund, toast, invalidateQueries]);

  if (isLoading) return <div className="min-h-screen bg-black flex items-center justify-center"><Loader2 className="w-8 h-8 text-primary animate-spin" /></div>;
  if (error || !pool) return <div className="min-h-screen bg-black flex items-center justify-center text-red-500">Error loading pool</div>;

  return (
    <div className="min-h-screen bg-black text-white overflow-hidden relative">
      <Navbar />

      {/* Hero Section with Black Hole */}
      <div className="relative h-[60vh] flex items-center justify-center border-b border-white/10">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(0,240,255,0.05)_0%,transparent_70%)]" />
        
        <div className="z-10 w-full max-w-2xl px-4 text-center">
          <BlackHoleCore 
            intensity={(pool.participantsCount ?? 0) / pool.maxParticipants} 
            status={pool.status} 
          />
        </div>

        {/* Overlay Stats */}
        <div className="absolute bottom-8 left-0 right-0 container mx-auto px-4 flex justify-between items-end">
          <div>
            <h1 className="text-5xl font-display font-black mb-2 tracking-tighter">
              {pool.tokenSymbol} <span className="text-primary">BLACK HOLE</span>
            </h1>
            <div className="flex items-center gap-4 text-sm font-tech text-muted-foreground uppercase">
              <span className="flex items-center gap-1"><Clock className="w-4 h-4" /> {pool.lockDuration}m Event Horizon</span>
              <span className="flex items-center gap-1"><Coins className="w-4 h-4" /> {pool.entryAmount} SOL Entry</span>
            </div>
          </div>
          
          <div className="text-right">
            <div className="text-4xl font-mono font-bold text-neon-cyan">
              {(pool.totalPot || 0).toFixed(2)} SOL
            </div>
            <div className="text-sm font-tech text-muted-foreground uppercase tracking-widest">Total Pot</div>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="container mx-auto px-4 py-8">
        <DevnetReadiness />
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Left Col: Actions & Status */}
          <div className="lg:col-span-2 space-y-6">
            
            {/* Winner Reveal Area */}
            <AnimatePresence mode="wait">
              {showRoulette ? (
                <motion.div 
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="bg-zinc-900 border border-yellow-500/50 rounded-lg overflow-hidden"
                >
                  <div className="bg-yellow-500/10 p-2 text-center text-yellow-500 font-bold uppercase text-xs tracking-widest border-b border-yellow-500/20">
                    SINGULARITY REACHED
                  </div>
                  <RouletteReveal 
                    participants={pool.participants}
                    winnerAddress={pool.winnerWallet}
                    onComplete={() => {
                      setWinnerRevealed(true);
                      // Keep roulette visible but mark as done
                    }}
                  />
                </motion.div>
              ) : winnerRevealed ? (
                <motion.div
                  initial={{ scale: 0.8, opacity: 0, filter: "blur(10px)" }}
                  animate={{ scale: 1, opacity: 1, filter: "blur(0px)" }}
                  className="relative bg-zinc-900/80 border-2 border-primary p-12 rounded-xl text-center shadow-[0_0_50px_rgba(0,240,255,0.3)] overflow-hidden"
                >
                  {/* Background pulse */}
                  <motion.div 
                    animate={{ opacity: [0.1, 0.3, 0.1] }}
                    transition={{ duration: 2, repeat: Infinity }}
                    className="absolute inset-0 bg-primary/20"
                  />
                  
                  <div className="relative z-10">
                    <motion.div
                      initial={{ y: 20 }}
                      animate={{ y: 0 }}
                      className="inline-block p-4 rounded-full bg-primary/20 mb-6 border border-primary/50"
                    >
                      <Trophy className="w-16 h-16 text-primary drop-shadow-[0_0_15px_rgba(0,240,255,1)]" />
                    </motion.div>
                    
                    <h2 className="text-5xl font-display font-black text-white mb-2 tracking-tighter italic uppercase">
                      ESCAPED THE <span className="text-primary">VOID</span>
                    </h2>
                    
                    <div className="bg-black/50 py-4 px-8 rounded-lg inline-block border border-white/5 mb-6">
                      <p className="font-mono text-primary text-2xl font-black tracking-widest">{pool.winnerWallet}</p>
                    </div>
                    
                    <div className="flex justify-center gap-12 items-center">
                      <div className="text-center">
                        <div className="text-sm text-muted-foreground font-tech uppercase tracking-widest mb-1">Amount Won</div>
                        <div className="text-3xl font-mono font-black text-white">{(pool.totalPot || 0).toFixed(2)} SOL</div>
                      </div>
                      <div className="w-px h-12 bg-white/10" />
                      <div className="text-center">
                        <div className="text-sm text-muted-foreground font-tech uppercase tracking-widest mb-1">Fee Breakdown</div>
                        <div className="text-lg font-mono text-muted-foreground">1.5% Protocol</div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ) : null}
            </AnimatePresence>

            {/* Action Card */}
            <div className="bg-white/5 border border-white/10 p-6 rounded-lg backdrop-blur-sm">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-display font-bold">STATUS: <span className={clsx(
                  pool.status === 'open' ? 'text-primary' : 'text-yellow-500'
                )}>{pool.status === 'locked' ? 'EVENT HORIZON' : pool.status.toUpperCase()}</span></h3>
                <div className="text-sm text-muted-foreground font-mono">
                  {pool.participantsCount} / {pool.maxParticipants} entities pulled
                </div>
              </div>

              <Progress value={((pool.participantsCount ?? 0) / pool.maxParticipants) * 100} className="h-2 mb-8 bg-white/10" />

              {pool.status === 'open' ? (
                hasJoined ? (
                  <Button disabled className="w-full h-14 text-lg font-bold bg-white/10 text-muted-foreground" data-testid="button-already-joined">
                    ALREADY JOINED
                  </Button>
                ) : (
                  <Button 
                    onClick={handleJoin} 
                    disabled={isJoining || !sdkConnected || !poolAddress}
                    className="w-full h-14 text-lg font-bold bg-primary text-black hover:bg-white hover:text-primary transition-all uppercase tracking-widest"
                    data-testid="button-join-pool"
                  >
                    {isJoining ? <Loader2 className="animate-spin" /> : `Get Pulled In (${pool.entryAmount} ${pool.tokenSymbol})`}
                  </Button>
                )
              ) : pool.status === 'cancelled' ? (
                canClaimRefund ? (
                  <Button 
                    onClick={handleClaimRefund}
                    disabled={isClaimingRefund || !sdkConnected}
                    className="w-full h-14 text-lg font-bold bg-green-600 text-white hover:bg-green-500 transition-all uppercase tracking-widest"
                    data-testid="button-claim-refund"
                  >
                    {isClaimingRefund ? <Loader2 className="animate-spin" /> : (
                      <>
                        <Gift className="w-5 h-5 mr-2" />
                        Claim Refund
                      </>
                    )}
                  </Button>
                ) : (
                  <Button disabled className="w-full h-14 text-lg font-bold bg-red-500/20 text-red-400 border border-red-500/30">
                    <XCircle className="w-5 h-5 mr-2" />
                    POOL CANCELLED
                  </Button>
                )
              ) : (
                <Button disabled className="w-full h-14 text-lg font-bold bg-white/5 text-muted-foreground border border-white/10">
                  EVENT HORIZON REACHED
                </Button>
              )}

              {canCancel && (
                <div className="mt-4 pt-4 border-t border-white/5">
                  <Button 
                    variant="destructive" 
                    onClick={handleCancel}
                    disabled={isCancelling || !sdkConnected}
                    className="w-full gap-2"
                    data-testid="button-cancel-pool"
                  >
                    {isCancelling ? <Loader2 className="w-4 h-4 animate-spin" /> : <Ban className="w-4 h-4" />}
                    Cancel Pool
                  </Button>
                  <p className="text-xs text-muted-foreground text-center mt-2">
                    Only available when pool has no participants
                  </p>
                </div>
              )}

              {!isConnected && pool.status === 'open' && !hasJoined && (
                <div className="mt-4 p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-md">
                  <p className="text-xs text-yellow-400 text-center">
                    Connect your wallet to join this Black Hole
                  </p>
                </div>
              )}

              {/* Donate Button - available when pool is not ended/cancelled */}
              {pool.status !== 'ended' && pool.status !== 'cancelled' && poolAddress && (
                <div className="mt-4 pt-4 border-t border-white/5">
                  <Button 
                    variant="outline"
                    onClick={() => {
                      console.log("=== DONATE_OPEN_MODAL ===");
                      setDonateModalOpen(true);
                    }}
                    disabled={!sdkConnected || !isConnected}
                    className="w-full gap-2 border-primary/50 text-primary hover:bg-primary/10"
                    data-testid="button-open-donate-modal"
                  >
                    <Heart className="w-4 h-4" />
                    Feed the Void (Donate)
                  </Button>
                </div>
              )}

              {/* Countdown Timer - only shows when pool is locked */}
              {pool.status === 'locked' && countdown !== null && (
                <div className="mt-6 p-4 bg-yellow-500/10 border border-yellow-500/30 rounded-lg text-center">
                  <div className="text-xs text-yellow-500 font-tech uppercase tracking-widest mb-2">
                    Event Horizon Countdown
                  </div>
                  {countdown > 0 ? (
                    <div className="text-3xl font-mono font-bold text-yellow-400">
                      {Math.floor(countdown / 60).toString().padStart(2, '0')}:
                      {(countdown % 60).toString().padStart(2, '0')}
                    </div>
                  ) : (
                    <div className="text-lg font-bold text-yellow-400">
                      Lock expired - awaiting resolution
                    </div>
                  )}
                </div>
              )}

              {/* Waiting for players - when pool is open */}
              {pool.status === 'open' && (
                <div className="mt-6 p-4 bg-primary/10 border border-primary/30 rounded-lg text-center">
                  <div className="text-xs text-primary font-tech uppercase tracking-widest mb-2">
                    Waiting for players
                  </div>
                  <div className="text-lg font-mono text-primary">
                    {pool.participantsCount || 0} / {pool.maxParticipants} joined
                  </div>
                </div>
              )}
            </div>

          </div>

          {/* Right Col: Participants List */}
          <div className="bg-white/5 border border-white/10 rounded-lg backdrop-blur-sm flex flex-col h-[500px]">
            <div className="p-4 border-b border-white/10 bg-white/5 flex items-center justify-between">
              <h3 className="font-tech font-bold uppercase tracking-wider flex items-center gap-2">
                <Users className="w-4 h-4 text-primary" /> Pulled Entities
              </h3>
              <span className="text-xs bg-black px-2 py-1 rounded text-muted-foreground font-mono">
                LIVE
              </span>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar">
              {pool.participants.length === 0 ? (
                <div className="text-center text-muted-foreground py-10 text-sm">
                  No participants yet.
                </div>
              ) : (
                pool.participants.map((p, i) => (
                  <motion.div 
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.05 }}
                    key={p.id} 
                    className={clsx(
                      "flex items-center gap-3 p-3 rounded bg-black/40 border border-white/5",
                      p.walletAddress === address && "border-primary/50 bg-primary/5"
                    )}
                  >
                    <img src={p.avatar || ""} className="w-8 h-8 rounded bg-white/10" alt="avatar" />
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-mono text-white truncate">
                        {p.walletAddress}
                      </div>
                      <div className="text-[10px] text-muted-foreground font-tech uppercase">
                        Pulled {new Date(p.joinedAt as unknown as string).toLocaleTimeString()}
                      </div>
                    </div>
                    {p.walletAddress === pool.winnerWallet && (
                      <Trophy className="w-4 h-4 text-yellow-500" />
                    )}
                  </motion.div>
                ))
              )}
            </div>
          </div>

        </div>
      </div>

      {/* Donate Modal */}
      <Dialog open={donateModalOpen} onOpenChange={setDonateModalOpen}>
        <DialogContent className="bg-zinc-900 border-primary/30 text-white">
          <DialogHeader>
            <DialogTitle className="text-xl font-display font-bold text-primary">
              Feed the Void
            </DialogTitle>
            <DialogDescription className="text-muted-foreground">
              Donate {pool?.tokenSymbol} tokens to increase the pot. Donations are non-refundable.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-sm font-tech uppercase text-muted-foreground">
                Amount ({pool?.tokenSymbol})
              </label>
              <Input
                type="number"
                step="0.0001"
                min="0"
                placeholder="Enter amount"
                value={donateAmount}
                onChange={(e) => {
                  console.log("=== DONATE_AMOUNT_SET ===", e.target.value);
                  setDonateAmount(e.target.value);
                }}
                className="bg-black/50 border-white/10 text-white font-mono"
                data-testid="input-donate-amount"
              />
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button
              variant="outline"
              onClick={() => setDonateModalOpen(false)}
              className="border-white/20"
              data-testid="button-cancel-donate"
            >
              Cancel
            </Button>
            <Button
              onClick={handleDonate}
              disabled={isDonating || !donateAmount || parseFloat(donateAmount) <= 0}
              className="bg-primary text-black hover:bg-primary/90"
              data-testid="button-confirm-donate"
            >
              {isDonating ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Heart className="w-4 h-4 mr-2" />}
              Donate
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
